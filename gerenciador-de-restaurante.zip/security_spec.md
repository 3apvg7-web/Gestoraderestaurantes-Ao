# Especificações de Segurança (Security Spec)

Este documento descreve as invariantes de dados, cargas maliciosas ("Dirty Dozen") e as regras de segurança para o banco de dados Firestore do Gerenciador de Restaurante.

## 1. Invariantes de Dados (Data Invariants)
- **Restaurantes**: O ID do documento do restaurante deve coincidir exatamente com o UID do proprietário autenticado (`request.auth.uid`). Nenhum outro usuário pode criar ou modificar este documento.
- **Assinaturas**: Os campos de assinatura (`activePlan`, `planStatus`, `planEndDate`) controlam o acesso geral. Se `planStatus` não for `"active"`, os clientes não poderão ver o cardápio ou realizar pedidos.
- **Cardápio (Menu Items)**: Itens do cardápio devem estar atrelados a um restaurante válido. Somente o dono desse restaurante correspondente pode criar, atualizar ou excluir itens.
- **Pedidos (Orders)**: Qualquer cliente pode criar um pedido em um restaurante ativo. Somente o dono do restaurante pode listar todos os pedidos ou atualizar o status (ex: Pendente -> Em Preparação -> Pronto). Clientes individuais podem ler seu próprio pedido se souberem o ID do documento (`get` seguro), mas são impedidos de fazer varredura (`list` bloqueado).

## 2. As Cargas Maliciosas ("Dirty Dozen")
Aqui estão 12 cargas projetadas para quebrar a segurança e como as regras as rejeitam com `PERMISSION_DENIED`:

1. **Tentativa de criar restaurante para outro UID**: Criar `/restaurants/hacker_uid` onde o proprietário é `auth.uid = victim_uid`.
   - *Resultado*: `PERMISSION_DENIED` (restrição de ID do documento igual ao UID).
2. **Atualização maliciosa de plano de outro restaurante**: Hacker tenta atualizar o plano de `/restaurants/victim_restaurant` para `"gold"`.
   - *Resultado*: `PERMISSION_DENIED` (verificação de proprietário).
3. **Criação de item de menu por não-proprietário**: Usuário autenticado tenta criar item no cardápio de `/restaurants/owner_uid`.
   - *Resultado*: `PERMISSION_DENIED` (Master Gate checa dono do restaurante).
4. **Leitura de todos os pedidos por um cliente**: Cliente malicioso tenta listar `/restaurants/owner_uid/orders`.
   - *Resultado*: `PERMISSION_DENIED` (somente o dono pode listar a coleção de pedidos).
5. **Injeção de caracteres gigantes em ID do Menu**: Tentativa de criar `/restaurants/owner_uid/menu_items/super_long_junk_id_1000_chars...`.
   - *Resultado*: `PERMISSION_DENIED` (validador `isValidId` restringe caracteres e tamanho).
6. **Injeção de campos ocultos (Shadow Fields)**: Criação de um item de menu contendo campos não mapeados como `isSystemAdmin: true`.
   - *Resultado*: `PERMISSION_DENIED` (validador estrito de chaves).
7. **Modificação do valor total de um pedido já pronto**: Cliente tenta atualizar o preço de um pedido `/restaurants/owner_uid/orders/order_1` após consumido.
   - *Resultado*: `PERMISSION_DENIED` (apenas proprietário pode atualizar pedidos).
8. **Substituição retroativa do campo `createdAt`**: Dono tenta alterar a data de criação original para falsificar histórico.
   - *Resultado*: `PERMISSION_DENIED` (campo `createdAt` é imutável na atualização).
9. **Pedido com dados de contato vazios**: Envio de pedido sem `customerName` ou `customerPhone`.
   - *Resultado*: `PERMISSION_DENIED` (validador de chaves obrigatórias).
10. **Fraude de ID de Autor de Pedido**: Hacker tenta criar um pedido atribuindo o ID de outro usuário.
    - *Resultado*: `PERMISSION_DENIED` (validação de identidade).
11. **Burla de plano expirado**: Cliente tenta carregar o cardápio ou fazer pedido em um restaurante com `planStatus: "expired"`.
    - *Resultado*: `PERMISSION_DENIED` (o Master Gate bloqueia acesso a subcoleções de restaurantes não ativos).
12. **Injeção de carimbo de data/hora do cliente**: Dono envia carimbo de data futuro no `updatedAt` para burlar expiração de plano.
    - *Resultado*: `PERMISSION_DENIED` (obrigatoriedade de usar `request.time` do servidor).
