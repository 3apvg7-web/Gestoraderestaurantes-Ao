export type PlanType = 'bala' | 'plus_bala' | 'gold' | 'none';
export type PlanStatusType = 'active' | 'expired' | 'none' | 'pending_approval';
export type OrderStatusType = 'pending' | 'preparing' | 'ready' | 'delivered' | 'canceled';
export type DeliveryType = 'delivery' | 'table';

export interface Restaurant {
  id: string;
  name: string;
  ownerId: string;
  ownerEmail: string;
  ownerPhone: string;
  description: string;
  logoUrl: string;
  supportPhone: string; // fallback or default to 923002202
  activePlan: PlanType;
  planStatus: PlanStatusType;
  planStartDate: string; // ISO String
  planEndDate: string; // ISO String
  createdAt: string; // ISO String
  updatedAt: string; // ISO String
  requestedPlan?: PlanType;
  paymentPhone?: string;
  paymentDate?: string;
}

export interface MenuItem {
  id: string;
  restaurantId: string;
  name: string;
  description: string;
  price: number; // in Kwanza (KZ)
  category: string; // Pratos, Bebidas, Sobremesas, Entradas, etc.
  imageUrl: string; // emoji or image path
  isAvailable: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface OrderItem {
  itemId: string;
  name: string;
  price: number;
  quantity: number;
  subtotal: number;
}

export interface Order {
  id: string;
  restaurantId: string;
  customerName: string;
  customerPhone: string;
  deliveryType: DeliveryType;
  deliveryAddress?: string;
  tableNumber?: string;
  notes?: string;
  items: OrderItem[];
  totalPrice: number;
  status: OrderStatusType;
  createdAt: string;
  updatedAt: string;
}

export interface PlanDetails {
  id: PlanType;
  name: string;
  price: number; // in KZ
  priceFormatted: string;
  servicePercent: number; // percentage of service, e.g. 20, 45, 100
  maxMenuItems: number;
  maxOrdersPerDay: number;
  features: string[];
}

export const PLAN_DETAILS: Record<PlanType, PlanDetails> = {
  none: {
    id: 'none',
    name: 'Sem Plano',
    price: 0,
    priceFormatted: '0 KZ',
    servicePercent: 0,
    maxMenuItems: 0,
    maxOrdersPerDay: 0,
    features: ['Nenhum serviço disponível']
  },
  bala: {
    id: 'bala',
    name: 'Plano Bala',
    price: 15000,
    priceFormatted: '15.000 KZ',
    servicePercent: 20,
    maxMenuItems: 6,
    maxOrdersPerDay: 15,
    features: [
      'Até 6 itens no cardápio (20% de capacidade)',
      'Até 15 pedidos diários',
      'Suporte via Multicaixa Express',
      'Apoio ao cliente padrão'
    ]
  },
  plus_bala: {
    id: 'plus_bala',
    name: 'Plano +Bala',
    price: 25000,
    priceFormatted: '25.000 KZ',
    servicePercent: 45,
    maxMenuItems: 15,
    maxOrdersPerDay: 40,
    features: [
      'Até 15 itens no cardápio (45% de capacidade)',
      'Até 40 pedidos diários',
      'Link personalizado para clientes',
      'Suporte prioritário'
    ]
  },
  gold: {
    id: 'gold',
    name: 'Plano Gold',
    price: 35000,
    priceFormatted: '35.000 KZ',
    servicePercent: 100,
    maxMenuItems: 999, // unlimited
    maxOrdersPerDay: 999, // unlimited
    features: [
      'Cardápio Ilimitado (100% de capacidade)',
      'Pedidos ilimitados diários',
      'Painel estatístico completo',
      'Gerenciamento em tempo real',
      'Suporte VIP 24h'
    ]
  }
};
