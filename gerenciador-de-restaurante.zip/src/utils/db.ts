import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  collection, 
  getDocs, 
  query, 
  where, 
  onSnapshot, 
  serverTimestamp, 
  Timestamp,
  deleteDoc
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { Restaurant, MenuItem, Order, PlanType } from '../types';

// Helper to safely map database stamps to ISO strings
function mapTimestamp(field: any): string {
  if (field instanceof Timestamp) {
    return field.toDate().toISOString();
  }
  if (field && typeof field === 'object' && 'seconds' in field) {
    return new Date(field.seconds * 1000).toISOString();
  }
  return field || '';
}

// Convert Firestore document to Restaurant type
export function mapDocToRestaurant(id: string, data: any): Restaurant {
  return {
    id,
    name: data.name || '',
    ownerId: data.ownerId || '',
    ownerEmail: data.ownerEmail || '',
    ownerPhone: data.ownerPhone || '',
    description: data.description || '',
    logoUrl: data.logoUrl || '🍽️',
    supportPhone: data.supportPhone || '923002202',
    activePlan: (data.activePlan || 'none') as Restaurant['activePlan'],
    planStatus: (data.planStatus || 'none') as Restaurant['planStatus'],
    planStartDate: mapTimestamp(data.planStartDate),
    planEndDate: mapTimestamp(data.planEndDate),
    createdAt: mapTimestamp(data.createdAt),
    updatedAt: mapTimestamp(data.updatedAt),
    requestedPlan: (data.requestedPlan || 'none') as Restaurant['requestedPlan'],
    paymentPhone: data.paymentPhone || '',
    paymentDate: mapTimestamp(data.paymentDate),
  };
}

// Convert Firestore document to MenuItem type
export function mapDocToMenuItem(id: string, data: any): MenuItem {
  return {
    id,
    restaurantId: data.restaurantId || '',
    name: data.name || '',
    description: data.description || '',
    price: Number(data.price || 0),
    category: data.category || '',
    imageUrl: data.imageUrl || '🍔',
    isAvailable: data.isAvailable !== false,
    createdAt: mapTimestamp(data.createdAt),
    updatedAt: mapTimestamp(data.updatedAt),
  };
}

// Convert Firestore document to Order type
export function mapDocToOrder(id: string, data: any): Order {
  return {
    id,
    restaurantId: data.restaurantId || '',
    customerName: data.customerName || '',
    customerPhone: data.customerPhone || '',
    deliveryType: data.deliveryType || 'table',
    deliveryAddress: data.deliveryAddress,
    tableNumber: data.tableNumber,
    notes: data.notes || '',
    items: (data.items || []).map((item: any) => ({
      itemId: item.itemId || '',
      name: item.name || '',
      price: Number(item.price || 0),
      quantity: Number(item.quantity || 0),
      subtotal: Number(item.subtotal || 0),
    })),
    totalPrice: Number(data.totalPrice || 0),
    status: data.status || 'pending',
    createdAt: mapTimestamp(data.createdAt),
    updatedAt: mapTimestamp(data.updatedAt),
  };
}

// --- RESTAURANT APIS ---

export async function getRestaurantById(restaurantId: string): Promise<Restaurant | null> {
  const path = `restaurants/${restaurantId}`;
  try {
    const docRef = doc(db, 'restaurants', restaurantId);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return mapDocToRestaurant(docSnap.id, docSnap.data());
    }
    return null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
    return null;
  }
}

export async function createRestaurantProfile(restaurantId: string, email: string, name: string): Promise<Restaurant> {
  const path = `restaurants/${restaurantId}`;
  const payload = {
    id: restaurantId,
    name: name,
    ownerId: restaurantId,
    ownerEmail: email,
    ownerPhone: '',
    description: 'Benvindo ao nosso restaurante! Veja nosso cardápio e faça seu pedido online.',
    logoUrl: '🍽️',
    supportPhone: '923002202',
    activePlan: 'none',
    planStatus: 'none',
    planStartDate: '',
    planEndDate: '',
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  try {
    const docRef = doc(db, 'restaurants', restaurantId);
    await setDoc(docRef, payload);
    const createdSnap = await getDoc(docRef);
    return mapDocToRestaurant(createdSnap.id, createdSnap.data());
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    throw error;
  }
}

export async function updateRestaurantProfile(restaurantId: string, updates: Partial<Restaurant>): Promise<void> {
  const path = `restaurants/${restaurantId}`;
  
  // Format dates appropriately
  const payload: Record<string, any> = {
    ...updates,
    updatedAt: serverTimestamp(),
  };

  // Ensure read-only properties or formats are removed/converted
  delete payload.id;
  delete payload.createdAt;
  delete payload.ownerId;
  delete payload.ownerEmail;

  if (updates.planStartDate) {
    payload.planStartDate = Timestamp.fromDate(new Date(updates.planStartDate));
  }
  if (updates.planEndDate) {
    payload.planEndDate = Timestamp.fromDate(new Date(updates.planEndDate));
  }
  if (updates.paymentDate) {
    payload.paymentDate = Timestamp.fromDate(new Date(updates.paymentDate));
  }

  try {
    const docRef = doc(db, 'restaurants', restaurantId);
    await updateDoc(docRef, payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

// Simulated active subscription activation (triggered by successful Multicaixa simulation)
export async function activateRestaurantPlan(restaurantId: string, plan: PlanType): Promise<void> {
  const startDate = new Date();
  const endDate = new Date();
  endDate.setMonth(endDate.getMonth() + 1); // 1 month plan validity

  const updates = {
    activePlan: plan,
    planStatus: 'active' as const,
    planStartDate: startDate.toISOString(),
    planEndDate: endDate.toISOString(),
    requestedPlan: 'none' as const,
    paymentPhone: '',
  };

  await updateRestaurantProfile(restaurantId, updates);
}

// Submits a plan request for admin approval
export async function requestRestaurantPlan(restaurantId: string, plan: PlanType, paymentPhone: string): Promise<void> {
  const updates = {
    planStatus: 'pending_approval' as const,
    requestedPlan: plan,
    paymentPhone: paymentPhone,
    paymentDate: new Date().toISOString(),
  };

  await updateRestaurantProfile(restaurantId, updates);
}

// Approves a requested plan, making it active
export async function approveRestaurantPlan(restaurantId: string, plan: PlanType): Promise<void> {
  const startDate = new Date();
  const endDate = new Date();
  endDate.setMonth(endDate.getMonth() + 1);

  const updates = {
    activePlan: plan,
    planStatus: 'active' as const,
    planStartDate: startDate.toISOString(),
    planEndDate: endDate.toISOString(),
    requestedPlan: 'none' as const,
    paymentPhone: '',
  };

  await updateRestaurantProfile(restaurantId, updates);
}

// Rejects a requested plan
export async function rejectRestaurantPlan(restaurantId: string): Promise<void> {
  const updates = {
    planStatus: 'none' as const,
    requestedPlan: 'none' as const,
    paymentPhone: '',
  };

  await updateRestaurantProfile(restaurantId, updates);
}

// Fetches all registered restaurants for the site administrator
export async function getAllRestaurants(): Promise<Restaurant[]> {
  const path = 'restaurants';
  try {
    const colRef = collection(db, 'restaurants');
    const querySnap = await getDocs(colRef);
    return querySnap.docs.map(docSnap => mapDocToRestaurant(docSnap.id, docSnap.data()));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

// --- MENU APIS ---

export async function getMenuItems(restaurantId: string): Promise<MenuItem[]> {
  const path = `restaurants/${restaurantId}/menu_items`;
  try {
    const colRef = collection(db, 'restaurants', restaurantId, 'menu_items');
    const querySnap = await getDocs(colRef);
    return querySnap.docs.map(docSnap => mapDocToMenuItem(docSnap.id, docSnap.data()));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

export async function createMenuItem(restaurantId: string, item: Omit<MenuItem, 'id' | 'restaurantId' | 'createdAt' | 'updatedAt'>): Promise<void> {
  // Generate random safe ID for document
  const itemId = 'item_' + Math.random().toString(36).substring(2, 11);
  const path = `restaurants/${restaurantId}/menu_items/${itemId}`;
  
  const payload = {
    id: itemId,
    restaurantId,
    name: item.name,
    description: item.description || '',
    price: Number(item.price),
    category: item.category,
    imageUrl: item.imageUrl || '🍔',
    isAvailable: item.isAvailable,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  try {
    const docRef = doc(db, 'restaurants', restaurantId, 'menu_items', itemId);
    await setDoc(docRef, payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateMenuItem(restaurantId: string, itemId: string, updates: Partial<MenuItem>): Promise<void> {
  const path = `restaurants/${restaurantId}/menu_items/${itemId}`;
  const payload = {
    ...updates,
    updatedAt: serverTimestamp(),
  };

  // Prevent read-only updates
  delete payload.id;
  delete payload.restaurantId;
  delete payload.createdAt;

  try {
    const docRef = doc(db, 'restaurants', restaurantId, 'menu_items', itemId);
    await updateDoc(docRef, payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteMenuItem(restaurantId: string, itemId: string): Promise<void> {
  const path = `restaurants/${restaurantId}/menu_items/${itemId}`;
  try {
    const docRef = doc(db, 'restaurants', restaurantId, 'menu_items', itemId);
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// --- ORDER APIS ---

export async function createOrder(restaurantId: string, orderData: Omit<Order, 'id' | 'restaurantId' | 'status' | 'createdAt' | 'updatedAt'>): Promise<Order> {
  const orderId = 'ped_' + Math.random().toString(36).substring(2, 11);
  const path = `restaurants/${restaurantId}/orders/${orderId}`;

  const payload = {
    id: orderId,
    restaurantId,
    customerName: orderData.customerName,
    customerPhone: orderData.customerPhone,
    deliveryType: orderData.deliveryType,
    deliveryAddress: orderData.deliveryAddress || '',
    tableNumber: orderData.tableNumber || '',
    notes: orderData.notes || '',
    items: orderData.items.map(i => ({
      itemId: i.itemId,
      name: i.name,
      price: i.price,
      quantity: i.quantity,
      subtotal: i.subtotal,
    })),
    totalPrice: orderData.totalPrice,
    status: 'pending',
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  try {
    const docRef = doc(db, 'restaurants', restaurantId, 'orders', orderId);
    await setDoc(docRef, payload);
    const createdSnap = await getDoc(docRef);
    return mapDocToOrder(createdSnap.id, createdSnap.data());
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    throw error;
  }
}

export async function updateOrderStatus(restaurantId: string, orderId: string, status: Order['status']): Promise<void> {
  const path = `restaurants/${restaurantId}/orders/${orderId}`;
  const payload = {
    status,
    updatedAt: serverTimestamp(),
  };

  try {
    const docRef = doc(db, 'restaurants', restaurantId, 'orders', orderId);
    await updateDoc(docRef, payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

// Real-time listener for Orders
export function listenToOrders(restaurantId: string, onUpdate: (orders: Order[]) => void, onError?: (err: Error) => void) {
  const path = `restaurants/${restaurantId}/orders`;
  const colRef = collection(db, 'restaurants', restaurantId, 'orders');
  
  return onSnapshot(colRef, (snapshot) => {
    const orders = snapshot.docs.map(docSnap => mapDocToOrder(docSnap.id, docSnap.data()));
    onUpdate(orders);
  }, (error) => {
    handleFirestoreError(error, OperationType.LIST, path);
    if (onError) onError(error instanceof Error ? error : new Error(String(error)));
  });
}

// Real-time listener for Menu Items
export function listenToMenuItems(restaurantId: string, onUpdate: (items: MenuItem[]) => void, onError?: (err: Error) => void) {
  const path = `restaurants/${restaurantId}/menu_items`;
  const colRef = collection(db, 'restaurants', restaurantId, 'menu_items');

  return onSnapshot(colRef, (snapshot) => {
    const items = snapshot.docs.map(docSnap => mapDocToMenuItem(docSnap.id, docSnap.data()));
    onUpdate(items);
  }, (error) => {
    handleFirestoreError(error, OperationType.LIST, path);
    if (onError) onError(error instanceof Error ? error : new Error(String(error)));
  });
}

// Real-time listener for specific Order
export function listenToOrderDetails(restaurantId: string, orderId: string, onUpdate: (order: Order | null) => void, onError?: (err: Error) => void) {
  const path = `restaurants/${restaurantId}/orders/${orderId}`;
  const docRef = doc(db, 'restaurants', restaurantId, 'orders', orderId);

  return onSnapshot(docRef, (docSnap) => {
    if (docSnap.exists()) {
      onUpdate(mapDocToOrder(docSnap.id, docSnap.data()));
    } else {
      onUpdate(null);
    }
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, path);
    if (onError) onError(error instanceof Error ? error : new Error(String(error)));
  });
}
