// Web Audio API Ding sound synthesizer to announce new orders
export function playNotificationSound() {
  try {
    // Check if window is defined and supports AudioContext
    if (typeof window === 'undefined') return;
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;

    const ctx = new AudioContextClass();
    
    // Create a pleasant double-chime ding
    const playChime = (time: number, freq: number, duration: number) => {
      const osc = ctx.createOscillator();
      const gainNode = ctx.createGain();
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, time);
      
      gainNode.gain.setValueAtTime(0, time);
      gainNode.gain.linearRampToValueAtTime(0.3, time + 0.05);
      gainNode.gain.exponentialRampToValueAtTime(0.001, time + duration);
      
      osc.connect(gainNode);
      gainNode.connect(ctx.destination);
      
      osc.start(time);
      osc.stop(time + duration);
    };

    const now = ctx.currentTime;
    // Pleasant high chime at two intervals
    playChime(now, 587.33, 0.4); // D5
    playChime(now + 0.12, 880, 0.6); // A5
  } catch (err) {
    console.warn('Audio notification was blocked or not supported by browser:', err);
  }
}
