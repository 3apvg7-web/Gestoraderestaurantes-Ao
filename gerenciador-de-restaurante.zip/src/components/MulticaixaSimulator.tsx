import React, { useState } from 'react';
import { Smartphone, CheckCircle, AlertCircle, PhoneCall, ArrowRight, Loader2 } from 'lucide-react';
import { PlanDetails, PlanType } from '../types';

interface MulticaixaSimulatorProps {
  plan: PlanDetails;
  onSuccess: (planId: PlanType, phoneNumber: string) => void;
  onClose: () => void;
}

export default function MulticaixaSimulator({ plan, onSuccess, onClose }: MulticaixaSimulatorProps) {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [step, setStep] = useState<'details' | 'waiting' | 'success'>('details');
  const [error, setError] = useState('');

  const handleRequestPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneNumber || phoneNumber.length < 9) {
      setError('Por favor, introduza um número de telefone válido com 9 dígitos.');
      return;
    }
    setError('');
    setStep('waiting');
  };

  const handleConfirmSimulation = () => {
    setStep('success');
    setTimeout(() => {
      onSuccess(plan.id, phoneNumber);
    }, 2000);
  };

  return (
    <div id="multicaixa-modal" className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-md overflow-hidden rounded-2xl bg-white border border-slate-200 text-slate-800 shadow-2xl">
        {/* Multicaixa Express Banner Header */}
        <div className="bg-[#0f172a] p-6 flex items-center justify-between text-white">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-slate-800 rounded-xl">
              <Smartphone className="h-6 w-6 text-white animate-bounce" />
            </div>
            <div>
              <h3 className="font-display font-bold text-lg tracking-tight">Multicaixa Express</h3>
              <p className="text-xs text-slate-400">Portal de Pagamentos Angola</p>
            </div>
          </div>
          <button 
            id="close-mc-sim"
            onClick={onClose}
            className="text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 p-1.5 rounded-lg text-sm transition-colors cursor-pointer"
          >
            Fechar
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6">
          {step === 'details' && (
            <div className="space-y-5">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <p className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Plano Selecionado</p>
                <div className="flex justify-between items-baseline mt-1">
                  <h4 className="font-display font-bold text-xl text-amber-500">{plan.name}</h4>
                  <span className="font-mono text-lg font-bold text-slate-800">{plan.priceFormatted}</span>
                </div>
                <p className="text-xs text-slate-500 mt-2">
                  Uso permitido de <strong className="text-slate-700">{plan.servicePercent}%</strong> dos recursos do aplicativo por 1 mês.
                </p>
              </div>

              {/* Instructions on paying */}
              <div className="p-4 rounded-xl bg-blue-50 border border-blue-200 text-blue-800 text-sm space-y-2">
                <div className="flex items-start space-x-2">
                  <AlertCircle className="h-5 w-5 text-blue-500 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold block text-blue-950">Instruções de Pagamento:</span>
                    O pagamento EXPRESS deve ser enviado para o número oficial de suporte:
                    <span className="block mt-1 font-mono text-base font-bold text-amber-500 text-center py-1 bg-white rounded border border-blue-200 shadow-sm">
                      923 002 202
                    </span>
                  </div>
                </div>
              </div>

              <form onSubmit={handleRequestPayment} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                    Telemóvel Associado ao MC Express
                  </label>
                  <div className="relative">
                    <span className="absolute left-4 top-3 text-slate-400 font-mono text-sm">+244</span>
                    <input
                      id="mc-phone-input"
                      type="tel"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, '').slice(0, 9))}
                      placeholder="923002202"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-16 pr-4 text-slate-800 font-mono placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 transition-all"
                      required
                    />
                  </div>
                  {error && <p className="text-red-500 text-xs mt-1.5 flex items-center gap-1"><AlertCircle className="h-3 w-3" /> {error}</p>}
                </div>

                <button
                  id="btn-request-mc"
                  type="submit"
                  className="w-full bg-amber-500 hover:bg-amber-600 text-white font-semibold py-3.5 px-4 rounded-xl flex items-center justify-center space-x-2 shadow-md shadow-amber-500/10 transition-all duration-200 cursor-pointer group"
                >
                  <span>Solicitar Confirmação no Telemóvel</span>
                  <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </form>
            </div>
          )}

          {step === 'waiting' && (
            <div className="text-center py-8 space-y-6">
              <div className="relative mx-auto w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center border border-slate-200 shadow-sm">
                <Loader2 className="h-10 w-10 text-amber-500 animate-spin" />
                <Smartphone className="absolute h-5 w-5 text-slate-400" />
              </div>

              <div className="space-y-2">
                <h4 className="font-display font-semibold text-lg text-slate-800">Confirmação Enviada!</h4>
                <p className="text-sm text-slate-600 max-w-xs mx-auto">
                  Enviamos um pedido de pagamento para o telemóvel <strong className="text-amber-500 font-mono">+244 {phoneNumber}</strong>.
                </p>
                <p className="text-xs text-slate-500">
                  Abra o aplicativo Multicaixa Express para confirmar a transação de <strong className="text-slate-700 font-mono">{plan.priceFormatted}</strong> para o número de suporte <strong className="text-slate-700">923002202</strong>.
                </p>
              </div>

              {/* Simulation Sandbox Bypass Helper */}
              <div className="pt-6 border-t border-slate-200 space-y-3">
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-800 text-left">
                  <strong>Painel de Simulação:</strong> Em um ambiente de produção real, este ecrã aguardaria o webhook do banco. Clique abaixo para simular que o pagamento foi aceito e autorizado pelo usuário no telemóvel.
                </div>
                <div className="flex gap-3">
                  <button
                    id="btn-cancel-sim"
                    onClick={() => setStep('details')}
                    className="flex-1 py-3 px-4 border border-slate-200 bg-white hover:bg-slate-50 rounded-xl text-xs transition-colors cursor-pointer text-slate-600"
                  >
                    Voltar
                  </button>
                  <button
                    id="btn-confirm-sim"
                    onClick={handleConfirmSimulation}
                    className="flex-1 py-3 px-4 bg-emerald-500 hover:bg-emerald-600 rounded-xl text-xs font-semibold text-white transition-all flex items-center justify-center space-x-1.5 cursor-pointer shadow-md shadow-emerald-500/10"
                  >
                    <CheckCircle className="h-4 w-4" />
                    <span>Simular Sucesso</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {step === 'success' && (
            <div className="text-center py-10 space-y-5 animate-scale-up">
              <div className="mx-auto w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center border-2 border-blue-500 text-blue-500 shadow-sm">
                <CheckCircle className="h-10 w-10 animate-pulse" />
              </div>

              <div className="space-y-1.5">
                <h4 className="font-display font-bold text-xl text-blue-600">Pagamento Solicitado!</h4>
                <p className="text-sm text-slate-600">Aguardando liberação do plano.</p>
                <p className="text-xs text-slate-500 max-w-xs mx-auto">
                  O seu pedido de ativação para o <strong className="text-amber-500 font-semibold">{plan.name}</strong> foi registado com sucesso usando o telemóvel <strong className="font-mono font-bold text-slate-700">{phoneNumber}</strong>.
                </p>
                <div className="text-xs text-slate-600 bg-slate-50 p-3 rounded-lg border border-slate-200 mt-3 text-left space-y-1">
                  <p className="font-semibold text-slate-800">Próximos Passos:</p>
                  <p>1. O administrador <strong>Nazael Diniz Alves Primo Giblin</strong> verificará o saldo e ativará o plano.</p>
                  <p>2. Você pode contactar pelo telefone <strong>923002202</strong> para agilizar a liberação.</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-50 p-4 px-6 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center space-x-1">
            <PhoneCall className="h-3 w-3 text-slate-400" />
            <span>Apoio: +244 923 002 202</span>
          </div>
          <span>BFA/BAI Express</span>
        </div>
      </div>
    </div>
  );
}
