import React, { useState, useEffect, useRef } from 'react';
import { Order, Restaurant, OrderStatusType } from '../types';
import { updateOrderStatus } from '../utils/db';
import { playNotificationSound } from '../utils/audio';
import { 
  Clock, 
  Phone, 
  MapPin, 
  MessageSquare, 
  Check, 
  AlertCircle, 
  Search, 
  Volume2, 
  VolumeX,
  UtensilsCrossed,
  Bell,
  BellOff
} from 'lucide-react';

interface OrderManagerProps {
  restaurant: Restaurant;
  orders: Order[];
}

export default function OrderManager({ restaurant, orders }: OrderManagerProps) {
  const [filter, setFilter] = useState<'all' | 'pending' | 'preparing' | 'ready' | 'archived'>('pending');
  const [search, setSearch] = useState('');
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const [pushPermission, setPushPermission] = useState<NotificationPermission>(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      return Notification.permission;
    }
    return 'default';
  });

  const hasNotificationSupport = typeof window !== 'undefined' && 'Notification' in window;

  const requestPushPermission = async () => {
    if (!hasNotificationSupport) {
      alert("O seu navegador não suporta notificações push.");
      return;
    }
    try {
      const permission = await Notification.requestPermission();
      setPushPermission(permission);
      if (permission === 'granted') {
        new Notification("Notificações Push Ativadas! 🔔", {
          body: "Agora receberá alertas de novos pedidos mesmo em segundo plano.",
          icon: restaurant.logoUrl && !restaurant.logoUrl.startsWith('data:') ? restaurant.logoUrl : undefined
        });
      }
    } catch (err) {
      console.error("Erro ao solicitar permissão de notificação:", err);
    }
  };

  // Keep track of previous orders to trigger sound on new incoming pending order
  const prevOrdersLengthRef = useRef<number>(orders.length);
  const prevPendingCountRef = useRef<number>(orders.filter(o => o.status === 'pending').length);

  useEffect(() => {
    const currentPendingCount = orders.filter(o => o.status === 'pending').length;
    const previousPendingCount = prevPendingCountRef.current;
    
    // If the count of pending orders increased, play sound and trigger push notification!
    if (currentPendingCount > previousPendingCount) {
      if (soundEnabled) {
        playNotificationSound();
      }

      // Show Browser Push Notification
      if (hasNotificationSupport && Notification.permission === 'granted') {
        const newOrdersCount = currentPendingCount - previousPendingCount;
        const latestOrder = orders.find(o => o.status === 'pending');
        const customerName = latestOrder ? latestOrder.customerName : 'Cliente';

        new Notification("Novo Pedido Recebido! 🔔", {
          body: newOrdersCount > 1 
            ? `Recebeu ${newOrdersCount} novos pedidos pendentes.` 
            : `Pedido de ${customerName} está aguardando aprovação!`,
          icon: restaurant.logoUrl && !restaurant.logoUrl.startsWith('data:') ? restaurant.logoUrl : undefined
        });
      }
    }
    
    prevOrdersLengthRef.current = orders.length;
    prevPendingCountRef.current = currentPendingCount;
  }, [orders, soundEnabled, restaurant.logoUrl]);

  const handleUpdateStatus = async (orderId: string, status: OrderStatusType) => {
    try {
      await updateOrderStatus(restaurant.id, orderId, status);
      // Update details view if active
      if (selectedOrder && selectedOrder.id === orderId) {
        setSelectedOrder(prev => prev ? { ...prev, status } : null);
      }
    } catch (err) {
      console.error('Error updating order status:', err);
    }
  };

  const formatTime = (isoString: string) => {
    if (!isoString) return 'Agora';
    try {
      const diffMs = new Date().getTime() - new Date(isoString).getTime();
      const diffMins = Math.floor(diffMs / 60000);
      if (diffMins < 1) return 'Agora mesmo';
      if (diffMins < 60) return `Há ${diffMins} min${diffMins > 1 ? 's' : ''}`;
      const diffHours = Math.floor(diffMins / 60);
      return `Há ${diffHours} hora${diffHours > 1 ? 's' : ''}`;
    } catch (e) {
      return '';
    }
  };

  // Filter orders based on status tab and search text
  const filteredOrders = orders.filter(order => {
    // Search filter
    const matchesSearch = 
      order.customerName.toLowerCase().includes(search.toLowerCase()) ||
      order.customerPhone.includes(search);

    if (!matchesSearch) return false;

    // Status tab filter
    if (filter === 'pending') return order.status === 'pending';
    if (filter === 'preparing') return order.status === 'preparing';
    if (filter === 'ready') return order.status === 'ready';
    if (filter === 'archived') return order.status === 'delivered' || order.status === 'canceled';
    return true; // 'all'
  }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()); // newest first

  const getStatusBadgeStyles = (status: OrderStatusType) => {
    switch (status) {
      case 'pending': return 'bg-amber-50 text-amber-600 border-amber-200 animate-pulse';
      case 'preparing': return 'bg-indigo-50 text-indigo-600 border-indigo-200';
      case 'ready': return 'bg-emerald-50 text-emerald-600 border-emerald-200';
      case 'delivered': return 'bg-slate-100 text-slate-500 border-slate-200';
      case 'canceled': return 'bg-red-50 text-red-600 border-red-200';
      default: return 'bg-slate-100 text-slate-500 border-slate-200';
    }
  };

  const getStatusLabel = (status: OrderStatusType) => {
    switch (status) {
      case 'pending': return 'Pendente';
      case 'preparing': return 'Na Cozinha';
      case 'ready': return 'Pronto para Entrega';
      case 'delivered': return 'Entregue';
      case 'canceled': return 'Cancelado';
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Title + Sound toggles */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="font-display font-bold text-2xl text-slate-800 flex items-center gap-2">
            Pedidos Recebidos
            <span className="text-xs bg-amber-50 text-amber-600 border border-amber-200 px-2 py-0.5 rounded-full font-sans font-semibold">
              Tempo Real
            </span>
          </h2>
          <p className="text-slate-500 text-sm mt-1">
            Gira a cozinha e as entregas dos pedidos realizados através do seu link.
          </p>
        </div>

        {/* Audio Alerts & Push Notification Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Sound Toggle */}
          <button
            id="btn-toggle-sound"
            onClick={() => {
              setSoundEnabled(!soundEnabled);
              if (!soundEnabled) playNotificationSound(); // demo
            }}
            className={`flex items-center space-x-2 py-2 px-4 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
              soundEnabled 
                ? 'bg-emerald-50 text-emerald-600 border-emerald-200 shadow-sm shadow-emerald-500/5' 
                : 'bg-slate-50 text-slate-500 border-slate-200'
            }`}
          >
            {soundEnabled ? (
              <>
                <Volume2 className="h-4 w-4 text-emerald-600 animate-pulse" />
                <span>Som Ativado</span>
              </>
            ) : (
              <>
                <VolumeX className="h-4 w-4 text-slate-400" />
                <span>Som Desativado</span>
              </>
            )}
          </button>

          {/* Push Notification Button */}
          {pushPermission === 'granted' ? (
            <button
              id="btn-push-test"
              onClick={() => {
                if (hasNotificationSupport) {
                  new Notification("Teste de Notificação! 🔔", {
                    body: "As suas notificações estão funcionando perfeitamente!",
                    icon: restaurant.logoUrl && !restaurant.logoUrl.startsWith('data:') ? restaurant.logoUrl : undefined
                  });
                }
              }}
              className="flex items-center space-x-2 py-2 px-4 rounded-xl text-xs font-semibold border bg-emerald-50 text-emerald-600 border-emerald-200 shadow-sm shadow-emerald-500/5 transition-all cursor-pointer"
            >
              <Bell className="h-4 w-4 text-emerald-600 animate-bounce" />
              <span>Notificações Push: Ativas</span>
            </button>
          ) : pushPermission === 'denied' ? (
            <div 
              title="Por favor, reative as permissões de notificação nas configurações do seu navegador para receber alertas."
              className="flex items-center space-x-2 py-2 px-4 rounded-xl text-xs font-semibold border bg-red-50 text-red-600 border-red-200 select-none cursor-not-allowed"
            >
              <BellOff className="h-4 w-4 text-red-500" />
              <span>Notificações Bloqueadas</span>
            </div>
          ) : (
            <button
              id="btn-request-push"
              onClick={requestPushPermission}
              className="flex items-center space-x-2 py-2 px-4 rounded-xl text-xs font-semibold border bg-amber-500 hover:bg-amber-600 text-white shadow-sm shadow-amber-500/10 transition-all cursor-pointer"
            >
              <Bell className="h-4 w-4 animate-pulse" />
              <span>Ativar Notificações Push</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
        <div className="flex flex-wrap gap-1.5">
          <button
            onClick={() => setFilter('pending')}
            className={`py-2 px-4 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              filter === 'pending' 
                ? 'bg-amber-500 text-white shadow-sm shadow-amber-500/10' 
                : 'bg-slate-50 text-slate-600 hover:text-slate-800 border border-slate-200'
            }`}
          >
            Pendentes ({orders.filter(o => o.status === 'pending').length})
          </button>
          <button
            onClick={() => setFilter('preparing')}
            className={`py-2 px-4 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              filter === 'preparing' 
                ? 'bg-indigo-500 text-white shadow-sm shadow-indigo-500/10' 
                : 'bg-slate-50 text-slate-600 hover:text-slate-800 border border-slate-200'
            }`}
          >
            Na Cozinha ({orders.filter(o => o.status === 'preparing').length})
          </button>
          <button
            onClick={() => setFilter('ready')}
            className={`py-2 px-4 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              filter === 'ready' 
                ? 'bg-emerald-500 text-white shadow-sm shadow-emerald-500/10' 
                : 'bg-slate-50 text-slate-600 hover:text-slate-800 border border-slate-200'
            }`}
          >
            Prontos ({orders.filter(o => o.status === 'ready').length})
          </button>
          <button
            onClick={() => setFilter('archived')}
            className={`py-2 px-4 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              filter === 'archived' 
                ? 'bg-slate-600 text-white shadow-sm shadow-slate-500/10' 
                : 'bg-slate-50 text-slate-600 hover:text-slate-800 border border-slate-200'
            }`}
          >
            Arquivados / Cancelados
          </button>
          <button
            onClick={() => setFilter('all')}
            className={`py-2 px-4 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              filter === 'all' 
                ? 'bg-slate-600 text-white shadow-sm shadow-slate-500/10' 
                : 'bg-slate-50 text-slate-600 hover:text-slate-800 border border-slate-200'
            }`}
          >
            Todos ({orders.length})
          </button>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3.5 top-2.5 h-4 w-4 text-slate-400" />
          <input
            id="order-search-input"
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Procurar cliente..."
            className="bg-slate-50 border border-slate-200 rounded-xl py-2 px-10 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 w-full md:w-60 transition-all"
          />
        </div>
      </div>

      {/* Orders Board */}
      {filteredOrders.length === 0 ? (
        <div className="text-center py-20 bg-white border border-slate-200 rounded-2xl shadow-sm">
          <Clock className="h-10 w-10 text-slate-300 mx-auto animate-pulse" />
          <h3 className="font-display font-semibold text-lg text-slate-700 mt-4">Nenhum pedido encontrado</h3>
          <p className="text-sm text-slate-500 max-w-sm mx-auto mt-1">
            Quando os clientes fizerem pedidos pelo link do cardápio, eles aparecerão aqui em tempo real com alertas sonoros!
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-5">
          {filteredOrders.map(order => (
            <div 
              key={order.id} 
              className="bg-white border border-slate-200 rounded-2xl overflow-hidden hover:border-slate-300 transition-all flex flex-col justify-between shadow-sm"
            >
              {/* Header card info */}
              <div className="p-4 border-b border-slate-200 flex items-start justify-between bg-slate-50">
                <div className="space-y-1">
                  <span className="font-mono text-[11px] font-bold text-slate-500 uppercase bg-slate-200 px-2 py-0.5 rounded">
                    ID: {order.id.toUpperCase().slice(-5)}
                  </span>
                  <h4 className="font-display font-bold text-slate-800 text-base pt-1">{order.customerName}</h4>
                  <div className="flex items-center space-x-1.5 text-xs text-slate-500 font-mono">
                    <Clock className="h-3.5 w-3.5 text-slate-400" />
                    <span>{formatTime(order.createdAt)}</span>
                  </div>
                </div>
                <div className={`px-2.5 py-1 text-[10px] font-bold uppercase rounded border ${getStatusBadgeStyles(order.status)}`}>
                  {getStatusLabel(order.status)}
                </div>
              </div>

              {/* Items Summary & Delivery Option */}
              <div className="p-4 space-y-3 flex-1">
                {/* Delivery details */}
                <div className="space-y-1.5 text-xs text-slate-600">
                  <div className="flex items-center space-x-2">
                    {order.deliveryType === 'delivery' ? (
                      <>
                        <MapPin className="h-3.5 w-3.5 text-orange-500 shrink-0" />
                        <span className="font-semibold text-orange-700">Entrega ao Domicílio:</span>
                        <span className="text-slate-600 truncate max-w-[180px]" title={order.deliveryAddress}>
                          {order.deliveryAddress}
                        </span>
                      </>
                    ) : (
                      <>
                        <UtensilsCrossed className="h-3.5 w-3.5 text-indigo-500 shrink-0" />
                        <span className="font-semibold text-indigo-700">Consumo Local (Mesa):</span>
                        <span className="font-mono bg-indigo-50 text-indigo-600 border border-indigo-200 px-2 py-0.5 rounded font-bold">
                          Mesa {order.tableNumber}
                        </span>
                      </>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    <Phone className="h-3.5 w-3.5 text-indigo-500 shrink-0" />
                    <span className="font-semibold">Telemóvel:</span>
                    <a 
                      href={`tel:${order.customerPhone}`} 
                      className="font-mono hover:underline text-indigo-600"
                    >
                      {order.customerPhone}
                    </a>
                  </div>
                </div>

                {/* Items Ordered */}
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-2">
                  <div className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Itens do Pedido</div>
                  <div className="divide-y divide-slate-100">
                    {order.items.map((item, idx) => (
                      <div key={idx} className="py-1.5 flex justify-between text-xs">
                        <span className="text-slate-700">
                          <strong className="text-amber-500 font-mono">{item.quantity}x</strong> {item.name}
                        </span>
                        <span className="text-slate-500 font-mono">{item.subtotal.toLocaleString('pt-PT')} KZ</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Order Remarks/Notes */}
                {order.notes && (
                  <div className="p-2 bg-amber-500/5 text-[11px] text-amber-800 rounded-lg flex items-start space-x-1.5 border border-amber-200/40">
                    <MessageSquare className="h-3.5 w-3.5 text-amber-500 shrink-0 mt-0.5" />
                    <span className="italic">"{order.notes}"</span>
                  </div>
                )}
              </div>

              {/* Total Price and Advanced actions */}
              <div className="p-4 border-t border-slate-200 bg-slate-50 flex flex-col space-y-3">
                <div className="flex justify-between items-baseline">
                  <span className="text-xs text-slate-500 font-semibold">Preço Total</span>
                  <span className="text-base font-mono font-bold text-slate-800">
                    {order.totalPrice.toLocaleString('pt-PT')} KZ
                  </span>
                </div>

                {/* State Machine Transition Actions */}
                <div className="flex gap-2">
                  {order.status === 'pending' && (
                    <>
                      <button
                        onClick={() => handleUpdateStatus(order.id, 'canceled')}
                        className="flex-1 py-2 border border-red-200 bg-white hover:bg-red-50 text-red-600 text-xs font-semibold rounded-xl transition-all cursor-pointer"
                      >
                        Recusar
                      </button>
                      <button
                        onClick={() => handleUpdateStatus(order.id, 'preparing')}
                        className="flex-1 py-2 bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold rounded-xl shadow-md shadow-amber-500/10 transition-all cursor-pointer flex items-center justify-center space-x-1"
                      >
                        <Check className="h-3.5 w-3.5" />
                        <span>Aceitar Cozinha</span>
                      </button>
                    </>
                  )}

                  {order.status === 'preparing' && (
                    <button
                      onClick={() => handleUpdateStatus(order.id, 'ready')}
                      className="w-full py-2.5 bg-indigo-500 hover:bg-indigo-600 text-white text-xs font-semibold rounded-xl shadow-md shadow-indigo-500/10 transition-all cursor-pointer flex items-center justify-center space-x-1"
                    >
                      <Check className="h-3.5 w-3.5" />
                      <span>Sinalizar como Pronto</span>
                    </button>
                  )}

                  {order.status === 'ready' && (
                    <button
                      onClick={() => handleUpdateStatus(order.id, 'delivered')}
                      className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-semibold rounded-xl shadow-md shadow-emerald-500/10 transition-all cursor-pointer flex items-center justify-center space-x-1"
                    >
                      <Check className="h-3.5 w-3.5" />
                      <span>Confirmar Entrega</span>
                    </button>
                  )}

                  {/* Archive option if completed */}
                  {(order.status === 'delivered' || order.status === 'canceled') && (
                    <div className="w-full text-center py-1 text-slate-400 text-xs italic">
                      Pedido finalizado e arquivado
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
