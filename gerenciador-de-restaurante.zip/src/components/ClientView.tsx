import React, { useState, useEffect } from 'react';
import { MenuItem, Restaurant, Order, OrderItem, DeliveryType } from '../types';
import { createOrder, listenToOrderDetails, listenToMenuItems } from '../utils/db';
import { 
  ShoppingBag, 
  MapPin, 
  UtensilsCrossed, 
  ChevronRight, 
  Clock, 
  AlertTriangle, 
  X, 
  Plus, 
  Minus, 
  Check, 
  Loader2,
  Trash2,
  PhoneCall
} from 'lucide-react';

interface ClientViewProps {
  restaurant: Restaurant;
}

export default function ClientView({ restaurant }: ClientViewProps) {
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [cart, setCart] = useState<{ item: MenuItem; quantity: number }[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  // Form State
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [deliveryType, setDeliveryType] = useState<DeliveryType>('table');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [tableNumber, setTableNumber] = useState('');
  const [notes, setNotes] = useState('');

  // Active tracking state
  const [trackedOrderId, setTrackedOrderId] = useState<string | null>(null);
  const [trackedOrder, setTrackedOrder] = useState<Order | null>(null);

  useEffect(() => {
    // Load menu items in real-time
    const unsubscribeMenu = listenToMenuItems(restaurant.id, (items) => {
      // Filter out unavailable items for clients
      setMenuItems(items.filter(item => item.isAvailable));
    });

    // Check localStorage for any active orders
    const savedOrderId = localStorage.getItem(`active_order_${restaurant.id}`);
    if (savedOrderId) {
      setTrackedOrderId(savedOrderId);
    }

    return () => {
      unsubscribeMenu();
    };
  }, [restaurant.id]);

  useEffect(() => {
    if (!trackedOrderId) {
      setTrackedOrder(null);
      return;
    }

    // Subscribe to tracked order details in real-time
    const unsubscribeOrder = listenToOrderDetails(restaurant.id, trackedOrderId, (order) => {
      setTrackedOrder(order);
    });

    return () => {
      unsubscribeOrder();
    };
  }, [restaurant.id, trackedOrderId]);

  const addToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(p => p.item.id === item.id);
      if (existing) {
        return prev.map(p => p.item.id === item.id ? { ...p, quantity: p.quantity + 1 } : p);
      }
      return [...prev, { item, quantity: 1 }];
    });
  };

  const updateQuantity = (itemId: string, delta: number) => {
    setCart(prev => {
      return prev.map(p => {
        if (p.item.id === itemId) {
          const newQty = p.quantity + delta;
          return newQty > 0 ? { ...p, quantity: newQty } : null;
        }
        return p;
      }).filter((p): p is { item: MenuItem; quantity: number } => p !== null);
    });
  };

  const removeFromCart = (itemId: string) => {
    setCart(prev => prev.filter(p => p.item.id !== itemId));
  };

  const getCartTotal = () => {
    return cart.reduce((sum, current) => sum + (current.item.price * current.quantity), 0);
  };

  const getCartCount = () => {
    return cart.reduce((sum, current) => sum + current.quantity, 0);
  };

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !customerPhone.trim() || cart.length === 0) return;
    if (deliveryType === 'delivery' && !deliveryAddress.trim()) return;
    if (deliveryType === 'table' && !tableNumber.trim()) return;

    setLoading(true);

    const orderItems: OrderItem[] = cart.map(c => ({
      itemId: c.item.id,
      name: c.item.name,
      price: c.item.price,
      quantity: c.quantity,
      subtotal: c.item.price * c.quantity
    }));

    try {
      const createdOrder = await createOrder(restaurant.id, {
        customerName,
        customerPhone,
        deliveryType,
        deliveryAddress: deliveryType === 'delivery' ? deliveryAddress : '',
        tableNumber: deliveryType === 'table' ? tableNumber : '',
        notes,
        items: orderItems,
        totalPrice: getCartTotal()
      });

      // Save to tracking state & localStorage
      setTrackedOrderId(createdOrder.id);
      localStorage.setItem(`active_order_${restaurant.id}`, createdOrder.id);

      // Reset cart and checkout modal
      setCart([]);
      setIsCheckoutOpen(false);
    } catch (err) {
      console.error('Error placing order:', err);
      alert('Houve um erro ao enviar o seu pedido. Por favor tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const handleCancelTracking = () => {
    if (window.confirm('Deseja parar de acompanhar este pedido? O pedido continuará na cozinha, mas sumirá desta tela.')) {
      localStorage.removeItem(`active_order_${restaurant.id}`);
      setTrackedOrderId(null);
      setTrackedOrder(null);
    }
  };

  const categories = ['Todos', ...Array.from(new Set(menuItems.map(item => item.category)))];

  const filteredItems = selectedCategory === 'Todos'
    ? menuItems
    : menuItems.filter(item => item.category === selectedCategory);

  const getStatusStep = (status: Order['status'] | undefined) => {
    switch (status) {
      case 'pending': return 1;
      case 'preparing': return 2;
      case 'ready': return 3;
      case 'delivered': return 4;
      default: return 1;
    }
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-800 pb-24 animate-fade-in">
      {/* Cover / Header Section */}
      <div className="relative bg-gradient-to-b from-amber-500/10 via-white to-[#f8fafc] px-4 py-8 sm:py-12 border-b border-slate-200">
        <div className="max-w-4xl mx-auto flex flex-col md:flex-row items-center gap-6 text-center md:text-left">
          <div className="h-20 w-20 sm:h-24 sm:w-24 rounded-3xl bg-amber-500 flex items-center justify-center font-bold text-4xl sm:text-5xl shadow-lg shadow-amber-500/20 text-white overflow-hidden shrink-0">
            {restaurant.logoUrl && (restaurant.logoUrl.startsWith('data:') || restaurant.logoUrl.startsWith('http')) ? (
              <img src={restaurant.logoUrl} alt={restaurant.name} className="w-full h-full object-cover" />
            ) : (
              restaurant.logoUrl || '🍽️'
            )}
          </div>
          <div className="space-y-2">
            <h1 className="font-display font-extrabold text-3xl sm:text-4xl text-slate-900 tracking-tight">
              {restaurant.name}
            </h1>
            <p className="text-slate-600 text-sm sm:text-base max-w-xl">
              {restaurant.description || 'Bem-vindo ao nosso cardápio digital. Faça o seu pedido com comodidade e acompanhe o progresso em tempo real.'}
            </p>
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 pt-1">
              <a 
                href={`tel:${restaurant.supportPhone || '923002202'}`}
                className="inline-flex items-center space-x-1.5 text-xs text-amber-600 font-semibold bg-amber-500/10 px-3 py-1.5 rounded-full border border-amber-500/20"
              >
                <PhoneCall className="h-3 w-3" />
                <span>Suporte: {restaurant.supportPhone || '923002202'}</span>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="max-w-4xl mx-auto px-4 py-6">
        {/* Real-time Order Tracking Banner - Dark Anchor Box */}
        {trackedOrderId && (
          <div className="mb-8 p-5 bg-[#0f172a] text-white rounded-2xl space-y-4 shadow-md border border-slate-800 relative overflow-hidden">
            <div className="absolute right-0 top-0 h-28 w-28 bg-indigo-500/5 rounded-full blur-2xl animate-pulse" />
            <div className="flex items-start justify-between relative z-10">
              <div className="space-y-1">
                <span className="text-[10px] bg-amber-500 text-white px-2 py-0.5 rounded-full font-mono uppercase font-bold tracking-wider">
                  Acompanhar Pedido Real-time
                </span>
                <h3 className="font-display font-bold text-lg text-white pt-1">
                  {trackedOrder ? `Olá ${trackedOrder.customerName}, o seu pedido está ativo!` : 'A carregar pedido...'}
                </h3>
                {trackedOrder && (
                  <p className="text-xs text-slate-400 font-mono">ID do Pedido: #{trackedOrder.id.toUpperCase().slice(-5)}</p>
                )}
              </div>
              <button
                onClick={handleCancelTracking}
                className="text-slate-400 hover:text-white p-1 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                title="Fechar acompanhamento"
              >
                <X className="h-4.5 w-4.5" />
              </button>
            </div>

            {trackedOrder && (
              <div className="space-y-4 relative z-10">
                {/* Visual state machine tracking bar */}
                <div className="relative pt-4 pb-2">
                  <div className="absolute top-6 left-0 right-0 h-1 bg-slate-800 rounded-full" />
                  <div 
                    className="absolute top-6 left-0 h-1 bg-emerald-500 rounded-full transition-all duration-500" 
                    style={{ width: `${((getStatusStep(trackedOrder.status) - 1) / 3) * 100}%` }}
                  />
                  
                  {/* Milestones */}
                  <div className="relative flex justify-between">
                    {[
                      { step: 1, label: 'Pendente', icon: Clock },
                      { step: 2, label: 'Na Cozinha', icon: UtensilsCrossed },
                      { step: 3, label: 'Pronto', icon: Check },
                      { step: 4, label: 'Entregue', icon: ShoppingBag }
                    ].map((m, idx) => {
                      const Icon = m.icon;
                      const active = getStatusStep(trackedOrder.status) >= m.step;
                      const isCurrent = getStatusStep(trackedOrder.status) === m.step;
                      return (
                        <div key={idx} className="flex flex-col items-center space-y-2">
                          <div className={`h-6.5 w-6.5 rounded-full flex items-center justify-center border-2 transition-all z-10 ${
                            isCurrent 
                              ? 'bg-amber-500 text-white border-amber-400 animate-pulse scale-110 shadow-sm' 
                              : active 
                              ? 'bg-emerald-500 text-white border-emerald-400' 
                              : 'bg-slate-900 text-slate-500 border-slate-800'
                          }`}>
                            <Icon className="h-3 w-3" />
                          </div>
                          <span className={`text-[10px] font-semibold tracking-tight transition-colors ${
                            isCurrent ? 'text-amber-400' : active ? 'text-emerald-400' : 'text-slate-500'
                          }`}>
                            {m.label}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Cancel block message */}
                {trackedOrder.status === 'canceled' && (
                  <div className="p-3 bg-red-950/20 border border-red-900/30 rounded-xl text-xs text-red-300 flex items-center gap-1.5">
                    <AlertTriangle className="h-4.5 w-4.5 text-red-400 shrink-0" />
                    <span>Lamentamos, mas o restaurante recusou ou cancelou o seu pedido. Por favor, contacte o suporte.</span>
                  </div>
                )}

                {/* Delivery summary details inside tracking banner */}
                <div className="p-3 bg-slate-950/50 rounded-xl border border-slate-800 text-xs space-y-1.5 text-slate-300">
                  <div className="flex justify-between">
                    <span>Mesa / Entrega:</span>
                    <strong className="text-white">
                      {trackedOrder.deliveryType === 'table' ? `Mesa ${trackedOrder.tableNumber}` : `Domicílio (${trackedOrder.deliveryAddress})`}
                    </strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Total do Pedido:</span>
                    <strong className="text-amber-500 font-mono">{trackedOrder.totalPrice.toLocaleString('pt-PT')} KZ</strong>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Categories Horizontal Rail */}
        <div className="flex items-center space-x-2 overflow-x-auto pb-4 scrollbar-none">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`py-2 px-4 rounded-xl text-xs font-semibold shrink-0 transition-all cursor-pointer ${
                selectedCategory === cat 
                  ? 'bg-amber-500 text-white shadow-sm shadow-amber-500/10' 
                  : 'bg-white border border-slate-200 text-slate-600 hover:text-slate-800 shadow-sm'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Menu Items Catalog Grid */}
        {filteredItems.length === 0 ? (
          <div className="text-center py-20 bg-white border border-slate-200 rounded-2xl shadow-sm">
            <ShoppingBag className="h-10 w-10 text-slate-300 mx-auto" />
            <h3 className="font-display font-semibold text-lg text-slate-700 mt-4">Nenhum prato disponível</h3>
            <p className="text-sm text-slate-500 max-w-sm mx-auto mt-1">
              O restaurante ainda não disponibilizou pratos nesta categoria ou o cardápio está em atualização.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredItems.map(item => (
              <div 
                key={item.id} 
                className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-slate-300 transition-all flex justify-between items-center shadow-sm"
              >
                <div className="flex items-start space-x-3.5">
                  {item.imageUrl && (item.imageUrl.startsWith('data:') || item.imageUrl.startsWith('http')) ? (
                    <div className="w-16 h-16 rounded-2xl overflow-hidden border border-slate-200 shrink-0 shadow-sm">
                      <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                    </div>
                  ) : (
                    <span className="text-3xl p-3 bg-slate-50 border border-slate-200 rounded-2xl block shrink-0 shadow-sm flex items-center justify-center w-16 h-16 leading-none">
                      {item.imageUrl || '🍔'}
                    </span>
                  )}
                  <div className="space-y-1">
                    <h4 className="font-display font-bold text-slate-800 text-base">{item.name}</h4>
                    <p className="text-xs text-slate-500 line-clamp-2 max-w-xs">{item.description || 'Delicioso item do cardápio.'}</p>
                    <p className="font-mono text-sm font-bold text-amber-500 pt-1">
                      {item.price.toLocaleString('pt-PT')} KZ
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => addToCart(item)}
                  className="p-2.5 bg-amber-500 hover:bg-amber-600 text-white rounded-xl transition-all cursor-pointer shadow-md shadow-amber-500/15 shrink-0"
                  title="Adicionar ao Carrinho"
                >
                  <Plus className="h-4.5 w-4.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Persistent Sticky Cart Drawer at bottom */}
      {cart.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200 p-4 shadow-2xl backdrop-blur-md animate-slide-up">
          <div className="max-w-4xl mx-auto flex items-center justify-between">
            <div className="flex items-center space-x-3.5">
              <div className="relative p-3 bg-amber-500 text-white rounded-xl shadow-md shadow-amber-500/15">
                <ShoppingBag className="h-5 w-5" />
                <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white font-mono text-[9px] font-black rounded-full h-5 w-5 flex items-center justify-center border-2 border-white">
                  {getCartCount()}
                </span>
              </div>
              <div>
                <span className="text-xs text-slate-400 block font-semibold">Total do seu carrinho</span>
                <span className="text-base font-mono font-bold text-slate-800">
                  {getCartTotal().toLocaleString('pt-PT')} KZ
                </span>
              </div>
            </div>

            <button
              id="btn-open-checkout"
              onClick={() => setIsCheckoutOpen(true)}
              className="bg-amber-500 hover:bg-amber-600 text-white font-bold py-3 px-6 rounded-xl flex items-center space-x-2 shadow-md shadow-amber-500/15 transition-all cursor-pointer group"
            >
              <span>Confirmar Pedido</span>
              <ChevronRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      )}

      {/* Checkout Sidebar/Modal */}
      {isCheckoutOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-lg bg-white border border-slate-200 text-slate-800 rounded-2xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
            {/* Header */}
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center space-x-2 text-slate-800">
                <ShoppingBag className="h-5 w-5 text-amber-500" />
                <h3 className="font-display font-bold text-lg">Finalizar o seu Pedido</h3>
              </div>
              <button
                onClick={() => setIsCheckoutOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Split view: Item summary & client details */}
            <form onSubmit={handlePlaceOrder} className="p-6 space-y-4 overflow-y-auto flex-1 bg-white">
              {/* Order Cart list review */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2.5">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Revisão dos Pratos</span>
                <div className="divide-y divide-slate-200 max-h-36 overflow-y-auto pr-1 space-y-1">
                  {cart.map(c => (
                    <div key={c.item.id} className="py-2 flex items-center justify-between text-xs">
                      <span className="text-slate-700 font-medium">{c.item.name}</span>
                      <div className="flex items-center space-x-3">
                        <div className="flex items-center bg-white border border-slate-200 rounded-lg p-0.5 shadow-sm">
                          <button
                            type="button"
                            onClick={() => updateQuantity(c.item.id, -1)}
                            className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
                          >
                            <Minus className="h-3 w-3" />
                          </button>
                          <span className="px-2 font-mono font-bold text-slate-800 text-xs">{c.quantity}</span>
                          <button
                            type="button"
                            onClick={() => updateQuantity(c.item.id, 1)}
                            className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
                          >
                            <Plus className="h-3 w-3" />
                          </button>
                        </div>
                        <span className="font-mono text-amber-500 font-bold">{(c.item.price * c.quantity).toLocaleString('pt-PT')} KZ</span>
                        <button
                          type="button"
                          onClick={() => removeFromCart(c.item.id)}
                          className="text-slate-400 hover:text-red-500 p-1 cursor-pointer"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="pt-2 border-t border-slate-200 flex justify-between font-bold text-sm">
                  <span>Total Geral</span>
                  <span className="text-amber-500 font-mono">{getCartTotal().toLocaleString('pt-PT')} KZ</span>
                </div>
              </div>

              {/* Customer Contact details */}
              <div className="space-y-3">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Suas Informações de Contacto</span>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Seu Nome *</label>
                    <input
                      type="text"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="Ex: João Silva"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-3.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 transition-all"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Telemóvel (Express / Chamadas) *</label>
                    <input
                      type="tel"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value.replace(/\D/g, ''))}
                      placeholder="Ex: 923000000"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-3.5 text-xs text-slate-800 font-mono placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 transition-all"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Delivery selectors */}
              <div className="space-y-3">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Como prefere consumir?</span>
                
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setDeliveryType('table')}
                    className={`py-3 px-4 rounded-xl border text-xs font-semibold flex items-center justify-center space-x-1.5 transition-all cursor-pointer ${
                      deliveryType === 'table'
                        ? 'bg-amber-50 border-amber-500 text-amber-800 font-bold shadow-sm'
                        : 'bg-slate-50 border-slate-200 text-slate-400 hover:text-slate-600'
                    }`}
                  >
                    <UtensilsCrossed className="h-4 w-4" />
                    <span>Consumo na Mesa</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeliveryType('delivery')}
                    className={`py-3 px-4 rounded-xl border text-xs font-semibold flex items-center justify-center space-x-1.5 transition-all cursor-pointer ${
                      deliveryType === 'delivery'
                        ? 'bg-amber-50 border-amber-500 text-amber-800 font-bold shadow-sm'
                        : 'bg-slate-50 border-slate-200 text-slate-400 hover:text-slate-600'
                    }`}
                  >
                    <MapPin className="h-4 w-4" />
                    <span>Entrega ao Domicílio</span>
                  </button>
                </div>

                {/* Sub-inputs based on choice */}
                {deliveryType === 'table' ? (
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Número da sua Mesa *</label>
                    <input
                      type="text"
                      value={tableNumber}
                      onChange={(e) => setTableNumber(e.target.value)}
                      placeholder="Ex: Mesa 4, Esplanada, etc."
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-3.5 text-xs text-slate-800 font-mono placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 transition-all"
                      required
                    />
                  </div>
                ) : (
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Endereço de Entrega Completo *</label>
                    <input
                      type="text"
                      value={deliveryAddress}
                      onChange={(e) => setDeliveryAddress(e.target.value)}
                      placeholder="Ex: Luanda, Talatona, Condomínio X, Casa Y"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-3.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 transition-all"
                      required
                    />
                  </div>
                )}
              </div>

              {/* Order Remarks */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">Observações do Pedido (Opcional)</label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Ex: Sem cebola, gelo no copo, carne mal passada."
                  rows={2}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-3.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 transition-all"
                />
              </div>

              {/* Submit footer actions inside checkout drawer */}
              <div className="pt-4 border-t border-slate-200 flex justify-end space-x-3 bg-slate-50 -mx-6 -mb-6 p-6">
                <button
                  type="button"
                  onClick={() => setIsCheckoutOpen(false)}
                  className="py-3 px-5 border border-slate-300 bg-white hover:bg-slate-100 rounded-xl text-sm font-semibold text-slate-700 transition-colors cursor-pointer shadow-sm"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="py-3 px-6 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-sm font-bold transition-all flex items-center space-x-2 shadow-md shadow-amber-500/10 cursor-pointer disabled:opacity-55 disabled:cursor-not-allowed"
                >
                  {loading ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      <span>A Enviar Pedido...</span>
                    </>
                  ) : (
                    <>
                      <Check className="h-4 w-4" />
                      <span>Enviar Pedido ao Chef</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
