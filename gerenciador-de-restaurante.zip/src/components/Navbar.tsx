import React from 'react';
import { User } from 'firebase/auth';
import { Phone, LogOut, ShieldAlert, Award, AlertCircle } from 'lucide-react';
import { Restaurant, PLAN_DETAILS } from '../types';
import { logoutUser } from '../firebase';

interface NavbarProps {
  user: User | null;
  restaurant: Restaurant | null;
  onLogout: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isClientMode?: boolean;
}

export default function Navbar({ user, restaurant, onLogout, activeTab, setActiveTab, isClientMode = false }: NavbarProps) {
  const getPlanBadgeColor = (plan: Restaurant['activePlan'] | undefined, status: Restaurant['planStatus'] | undefined) => {
    if (status !== 'active') return 'bg-slate-800 text-slate-400 border-slate-700';
    switch (plan) {
      case 'gold': return 'bg-amber-500/10 text-amber-400 border-amber-500/30 font-bold';
      case 'plus_bala': return 'bg-indigo-500/10 text-indigo-400 border-indigo-500/30';
      case 'bala': return 'bg-sky-500/10 text-sky-400 border-sky-500/30';
      default: return 'bg-slate-800 text-slate-400 border-slate-700';
    }
  };

  const getPlanLabel = (plan: Restaurant['activePlan'] | undefined, status: Restaurant['planStatus'] | undefined) => {
    if (status === 'expired') return 'Expirado ⚠️';
    if (!plan || plan === 'none') return 'Sem Plano ❌';
    return PLAN_DETAILS[plan]?.name || 'Sem Plano';
  };

  return (
    <nav className="sticky top-0 z-40 bg-[#0f172a] border-b border-slate-800 backdrop-blur-md px-4 py-3.5 sm:px-6">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Logo and Brand */}
        <div className="flex items-center space-x-3">
          <div className="h-10 w-10 rounded-xl bg-amber-500 flex items-center justify-center font-bold text-lg text-white shadow-md shadow-amber-500/10 overflow-hidden shrink-0">
            {restaurant?.logoUrl && (restaurant.logoUrl.startsWith('data:') || restaurant.logoUrl.startsWith('http')) ? (
              <img src={restaurant.logoUrl} alt={restaurant.name} className="w-full h-full object-cover" />
            ) : (
              restaurant?.logoUrl || '🍽️'
            )}
          </div>
          <div>
            <span className="font-display font-bold text-base sm:text-lg tracking-tight text-white flex items-center gap-1.5">
              {restaurant?.name || 'ChefExpress'}
              {isClientMode && (
                <span className="text-[10px] bg-amber-500/15 text-amber-400 border border-amber-500/25 rounded px-1.5 py-0.5">
                  Menu Cliente
                </span>
              )}
            </span>
            <span className="text-xs text-slate-400 block -mt-0.5 sm:inline sm:ml-1 sm:mt-0">
              {isClientMode ? 'Visualização do Cardápio' : 'Painel de Gestão'}
            </span>
          </div>
        </div>

        {/* Action Items */}
        <div className="flex items-center space-x-3 sm:space-x-4">
          {/* Support Line */}
          <a
            href="tel:923002202"
            className="flex items-center space-x-1.5 bg-slate-800/60 hover:bg-slate-800 text-slate-300 hover:text-white px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl text-xs font-semibold border border-slate-700/40 transition-all cursor-pointer"
            title="Apoio ao Cliente"
          >
            <Phone className="h-3.5 w-3.5 text-amber-500" />
            <span className="hidden sm:inline">Apoio: 923002202</span>
            <span className="sm:hidden font-mono">923002202</span>
          </a>

          {!isClientMode && user && restaurant && (
            <>
              {/* Plan Badge */}
              <button
                id="navbar-plan-badge"
                onClick={() => setActiveTab('assinatura')}
                className={`hidden md:flex items-center space-x-1.5 border px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${getPlanBadgeColor(
                  restaurant.activePlan,
                  restaurant.planStatus
                )}`}
              >
                {restaurant.planStatus === 'active' ? (
                  <Award className="h-3.5 w-3.5" />
                ) : (
                  <ShieldAlert className="h-3.5 w-3.5 text-red-400" />
                )}
                <span>{getPlanLabel(restaurant.activePlan, restaurant.planStatus)}</span>
              </button>

              {/* Log Out */}
              <button
                id="navbar-logout-btn"
                onClick={onLogout}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-800/50 rounded-xl transition-all cursor-pointer"
                title="Sair da Conta"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
