import React, { useState } from 'react';
import { MenuItem, Restaurant, PLAN_DETAILS, PlanType } from '../types';
import { createMenuItem, updateMenuItem, deleteMenuItem } from '../utils/db';
import { Plus, Edit2, Trash2, Check, X, AlertTriangle, Sparkles, SlidersHorizontal } from 'lucide-react';
import { compressImage } from '../utils/imageCompressor';

interface MenuEditorProps {
  restaurant: Restaurant;
  menuItems: MenuItem[];
  onNavigateToSubscription: () => void;
}

const EMOJIS = ['🍔', '🍕', '🍗', '🥩', '🍟', '🍣', '🥗', '🍝', '🍲', '🍰', '🍦', '🍩', '🥤', '🍺', '🍷', '🍹', '☕', '🥐', '🥪', '🍤'];
const CATEGORIES = ['Pratos Principais', 'Bebidas', 'Sobremesas', 'Entradas / Petiscos', 'Outros'];

export default function MenuEditor({ restaurant, menuItems, onNavigateToSubscription }: MenuEditorProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);
  
  // Form State
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [imageUrl, setImageUrl] = useState(EMOJIS[0]);
  const [imageType, setImageType] = useState<'emoji' | 'gallery'>('emoji');
  const [isAvailable, setIsAvailable] = useState(true);
  const [compressing, setCompressing] = useState(false);

  const [filterCategory, setFilterCategory] = useState('Todos');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const currentPlanDetails = PLAN_DETAILS[restaurant.activePlan || 'none'];
  const maxItemsAllowed = currentPlanDetails.maxMenuItems;
  const isLimitReached = restaurant.planStatus !== 'active' || menuItems.length >= maxItemsAllowed;

  const handleOpenAdd = () => {
    if (isLimitReached) {
      setError(`O seu plano atual (${currentPlanDetails.name}) atingiu o limite de ${maxItemsAllowed} itens.`);
      return;
    }
    setName('');
    setDescription('');
    setPrice('');
    setCategory(CATEGORIES[0]);
    setImageUrl(EMOJIS[0]);
    setImageType('emoji');
    setIsAvailable(true);
    setError('');
    setIsAdding(true);
  };

  const handleOpenEdit = (item: MenuItem) => {
    setEditingItem(item);
    setName(item.name);
    setDescription(item.description);
    setPrice(item.price.toString());
    setCategory(item.category);
    setImageUrl(item.imageUrl);
    const isCustom = item.imageUrl && (item.imageUrl.startsWith('data:') || item.imageUrl.startsWith('http://') || item.imageUrl.startsWith('https://'));
    setImageType(isCustom ? 'gallery' : 'emoji');
    setIsAvailable(item.isAvailable);
    setError('');
  };

  const handleImageFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 50 * 1024 * 1024) {
        alert("A imagem selecionada é muito pesada! Por favor, escolha uma imagem com menos de 50 MB.");
        return;
      }
      setCompressing(true);
      try {
        const compressedBase64 = await compressImage(file);
        setImageUrl(compressedBase64);
      } catch (err) {
        console.error("Erro ao processar imagem:", err);
        alert("Ocorreu um erro ao processar a imagem. Por favor, tente com outro arquivo.");
      } finally {
        setCompressing(false);
      }
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !price || Number(price) <= 0) {
      setError('Por favor preencha todos os campos obrigatórios corretamente.');
      return;
    }

    setLoading(true);
    setError('');

    try {
      if (editingItem) {
        // Edit Item
        await updateMenuItem(restaurant.id, editingItem.id, {
          name,
          description,
          price: Number(price),
          category,
          imageUrl,
          isAvailable,
        });
        setEditingItem(null);
      } else {
        // Add Item (Double check limits)
        if (menuItems.length >= maxItemsAllowed) {
          throw new Error(`Limite de ${maxItemsAllowed} itens atingido! Atualize o seu plano para cadastrar mais.`);
        }
        await createMenuItem(restaurant.id, {
          name,
          description,
          price: Number(price),
          category,
          imageUrl,
          isAvailable,
        });
        setIsAdding(false);
      }
    } catch (err: any) {
      setError(err.message || 'Erro ao guardar item do cardápio.');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (itemId: string) => {
    if (!window.confirm('Tem certeza que pretende eliminar este item do cardápio?')) return;
    setLoading(true);
    try {
      await deleteMenuItem(restaurant.id, itemId);
    } catch (err: any) {
      setError('Erro ao eliminar item.');
    } finally {
      setLoading(false);
    }
  };

  const filteredItems = filterCategory === 'Todos' 
    ? menuItems 
    : menuItems.filter(item => item.category === filterCategory);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top action header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="font-display font-bold text-2xl text-slate-800">Cardápio do Restaurante</h2>
          <p className="text-slate-500 text-sm mt-1">
            Cadastre os pratos, bebidas e preços que aparecerão no link dos seus clientes.
          </p>
        </div>
        <button
          id="btn-add-menu-item"
          onClick={handleOpenAdd}
          disabled={restaurant.planStatus !== 'active'}
          className={`flex items-center justify-center space-x-2 py-3 px-5 rounded-xl font-semibold transition-all cursor-pointer ${
            restaurant.planStatus !== 'active'
              ? 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
              : 'bg-amber-500 hover:bg-amber-600 text-white shadow-md shadow-amber-500/10'
          }`}
        >
          <Plus className="h-4 w-4" />
          <span>Novo Prato / Produto</span>
        </button>
      </div>

      {/* Expiry Warning or Limit Warnings */}
      {restaurant.planStatus !== 'active' ? (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 flex flex-col md:flex-row md:items-center md:justify-between gap-4 text-red-800">
          <div className="flex items-start space-x-3">
            <AlertTriangle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
            <div>
              <strong className="text-red-950 font-semibold">Serviço Suspenso ou Sem Plano Ativo</strong>
              <p className="text-sm text-red-700 mt-1">
                A sua assinatura expirou ou ainda não foi paga. Seus clientes não podem ver o cardápio ou realizar pedidos.
              </p>
            </div>
          </div>
          <button
            id="go-to-sub-from-menu"
            onClick={onNavigateToSubscription}
            className="bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-lg text-xs transition-colors cursor-pointer self-start md:self-center border border-red-600 shadow-sm"
          >
            Pagar Plano Agora
          </button>
        </div>
      ) : isLimitReached ? (
        <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 flex flex-col md:flex-row md:items-center md:justify-between gap-4 text-amber-800">
          <div className="flex items-start space-x-3">
            <Sparkles className="h-5 w-5 text-amber-500 shrink-0 mt-0.5 animate-pulse" />
            <div>
              <strong className="text-amber-950 font-semibold">Limite de Itens Atingido ({menuItems.length} / {maxItemsAllowed})</strong>
              <p className="text-sm text-amber-700 mt-1">
                O seu plano atual (<span className="capitalize">{restaurant.activePlan}</span>) tem um limite de {maxItemsAllowed} itens. Libere mais espaço ou adquira o Plano Gold para ter itens ilimitados.
              </p>
            </div>
          </div>
          <button
            id="upgrade-sub-from-menu"
            onClick={onNavigateToSubscription}
            className="bg-amber-500 hover:bg-amber-600 text-white font-semibold py-2 px-4 rounded-lg text-xs transition-colors cursor-pointer self-start md:self-center shadow-md shadow-amber-500/10"
          >
            Fazer Upgrade (Plano Gold)
          </button>
        </div>
      ) : (
        <div className="p-4 rounded-xl bg-white border border-slate-200 flex items-center justify-between text-slate-600 text-sm shadow-sm">
          <span>Capacidade do cardápio utilizado: <strong>{menuItems.length}</strong> de <strong>{maxItemsAllowed === 999 ? 'Ilimitado' : maxItemsAllowed}</strong> itens disponíveis.</span>
          <span className="text-xs text-amber-600 font-semibold bg-amber-50 px-2 py-1 rounded-lg border border-amber-200">
            {currentPlanDetails.servicePercent}% Ativado
          </span>
        </div>
      )}

      {/* Category Filtering Rail */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-none">
        <div className="p-2 bg-white border border-slate-200 rounded-lg text-slate-400 shrink-0 shadow-sm">
          <SlidersHorizontal className="h-4 w-4" />
        </div>
        <button
          onClick={() => setFilterCategory('Todos')}
          className={`py-2 px-4 rounded-xl text-xs font-semibold shrink-0 transition-all cursor-pointer ${
            filterCategory === 'Todos' 
              ? 'bg-amber-500 text-white shadow-sm shadow-amber-500/10' 
              : 'bg-white border border-slate-200 text-slate-600 hover:text-slate-800'
          }`}
        >
          Todos ({menuItems.length})
        </button>
        {CATEGORIES.map(cat => {
          const count = menuItems.filter(item => item.category === cat).length;
          return (
            <button
              key={cat}
              onClick={() => setFilterCategory(cat)}
              className={`py-2 px-4 rounded-xl text-xs font-semibold shrink-0 transition-all cursor-pointer ${
                filterCategory === cat 
                  ? 'bg-amber-500 text-white shadow-sm shadow-amber-500/10' 
                  : 'bg-white border border-slate-200 text-slate-600 hover:text-slate-800'
              }`}
            >
              {cat} ({count})
            </button>
          );
        })}
      </div>

      {/* Grid of items */}
      {filteredItems.length === 0 ? (
        <div className="text-center py-16 bg-white border border-slate-200 rounded-2xl shadow-sm">
          <span className="text-4xl block">🥑</span>
          <h3 className="font-display font-semibold text-lg text-slate-700 mt-4">Nenhum produto cadastrado</h3>
          <p className="text-sm text-slate-500 max-w-sm mx-auto mt-1">
            {filterCategory === 'Todos' 
              ? 'Adicione pratos, sobremesas e bebidas no seu cardápio para começar a vender.' 
              : `Nenhum item cadastrado na categoria ${filterCategory}.`}
          </p>
          {filterCategory === 'Todos' && restaurant.planStatus === 'active' && (
            <button
              onClick={handleOpenAdd}
              className="mt-5 inline-flex items-center space-x-2 text-sm font-semibold bg-amber-500 hover:bg-amber-600 text-white py-2 px-4 rounded-xl cursor-pointer transition-colors shadow-sm"
            >
              <Plus className="h-4 w-4" />
              <span>Adicionar Primeiro Item</span>
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredItems.map(item => (
            <div 
              key={item.id} 
              className={`p-4 rounded-2xl bg-white border hover:border-slate-300 shadow-sm transition-all flex justify-between ${
                item.isAvailable ? 'border-slate-200' : 'border-slate-200 opacity-70 bg-slate-50'
              }`}
            >
              <div className="flex items-start space-x-3.5">
                {item.imageUrl && (item.imageUrl.startsWith('data:') || item.imageUrl.startsWith('http')) ? (
                  <div className="w-16 h-16 rounded-2xl overflow-hidden border border-slate-200 shrink-0 shadow-sm">
                    <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                  </div>
                ) : (
                  <span className="text-3xl p-3 bg-slate-50 border border-slate-200 rounded-2xl block shrink-0 shadow-sm flex items-center justify-center w-16 h-16 leading-none">
                    {item.imageUrl || '🍔'}
                  </span>
                )}
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5">
                    <h4 className="font-display font-bold text-slate-800">{item.name}</h4>
                    {!item.isAvailable && (
                      <span className="bg-red-100 text-red-600 border border-red-200 rounded px-1.5 py-0.5 text-[9px] uppercase font-bold tracking-wider">
                        Esgotado
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 line-clamp-2 max-w-xs">{item.description || 'Sem descrição cadastrada.'}</p>
                  <p className="font-mono text-sm font-bold text-amber-500 pt-1">
                    {item.price.toLocaleString('pt-PT')} KZ
                  </p>
                  <span className="inline-block bg-slate-100 text-slate-500 text-[10px] px-2 py-0.5 rounded border border-slate-200">
                    {item.category}
                  </span>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex flex-col justify-between items-end shrink-0 pl-2">
                <div className="flex gap-1.5">
                  <button
                    onClick={() => handleOpenEdit(item)}
                    className="p-2 bg-slate-50 hover:bg-slate-100 text-slate-600 hover:text-slate-800 rounded-lg transition-colors border border-slate-200 cursor-pointer shadow-sm"
                    title="Editar Item"
                  >
                    <Edit2 className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => handleDelete(item.id)}
                    className="p-2 bg-slate-50 hover:bg-red-50 text-slate-500 hover:text-red-500 rounded-lg transition-colors border border-slate-200 cursor-pointer shadow-sm"
                    title="Eliminar Item"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Adding / Editing Modal */}
      {(isAdding || editingItem) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-lg bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col text-slate-800">
            {/* Header */}
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <h3 className="font-display font-bold text-lg text-slate-800">
                {editingItem ? 'Editar Prato / Produto' : 'Cadastrar Prato / Produto'}
              </h3>
              <button
                onClick={() => {
                  setIsAdding(false);
                  setEditingItem(null);
                }}
                className="text-slate-400 hover:text-slate-600 p-1 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSave} className="p-6 space-y-4 overflow-y-auto flex-1 bg-white">
              {error && (
                <div className="p-3.5 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs flex items-center gap-1.5">
                  <AlertTriangle className="h-4 w-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {/* Title Input */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                  Nome do Prato / Bebida *
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ex: Calulu de Peixe, Cerveja Cuca, etc."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 transition-all"
                  required
                />
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                  Descrição / Ingredientes
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Ex: Peixe fresco, óleo de palma, quiabos, acompanhado com pirão."
                  rows={2}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 transition-all"
                />
              </div>

              {/* Category and Price Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                    Categoria *
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-sm text-slate-800 focus:outline-none focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 transition-all cursor-pointer"
                  >
                    {CATEGORIES.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                    Preço (KZ) *
                  </label>
                  <input
                    type="number"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    placeholder="Ex: 4500"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-sm text-slate-800 font-mono placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 transition-all"
                    required
                    min={1}
                  />
                </div>
              </div>

              {/* Emoji or Gallery Representative Picker */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400">
                    Imagem ou Ícone do Prato *
                  </label>
                  <div className="flex bg-slate-100 p-0.5 rounded-lg border border-slate-200">
                    <button
                      type="button"
                      onClick={() => {
                        setImageType('emoji');
                        if (imageUrl.startsWith('data:') || imageUrl.startsWith('http')) {
                          setImageUrl(EMOJIS[0]);
                        }
                      }}
                      className={`px-3 py-1 text-xs font-bold rounded-md transition-all cursor-pointer ${
                        imageType === 'emoji' 
                          ? 'bg-white text-slate-800 shadow-sm' 
                          : 'text-slate-500 hover:text-slate-700'
                      }`}
                    >
                      Emoji
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setImageType('gallery');
                        if (!imageUrl.startsWith('data:') && !imageUrl.startsWith('http')) {
                          setImageUrl('');
                        }
                      }}
                      className={`px-3 py-1 text-xs font-bold rounded-md transition-all cursor-pointer ${
                        imageType === 'gallery' 
                          ? 'bg-white text-slate-800 shadow-sm' 
                          : 'text-slate-500 hover:text-slate-700'
                      }`}
                    >
                      Galeria 📸
                    </button>
                  </div>
                </div>

                {imageType === 'emoji' ? (
                  <div className="flex flex-wrap gap-2 p-3 bg-slate-50 rounded-xl border border-slate-200 max-h-32 overflow-y-auto">
                    {EMOJIS.map(emoji => (
                      <button
                        key={emoji}
                        type="button"
                        onClick={() => setImageUrl(emoji)}
                        className={`text-2xl p-2 rounded-xl transition-all hover:bg-slate-200 border cursor-pointer ${
                          imageUrl === emoji ? 'bg-amber-50 border-amber-500 scale-110 shadow-sm' : 'border-transparent'
                        }`}
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex flex-col items-center justify-center gap-3">
                    {imageUrl && (imageUrl.startsWith('data:') || imageUrl.startsWith('http')) ? (
                      <div className="relative group w-20 h-20 rounded-2xl overflow-hidden border border-slate-300 shadow-sm">
                        <img 
                          src={imageUrl} 
                          alt="Previsualização" 
                          className="w-full h-full object-cover"
                        />
                        <button
                          type="button"
                          onClick={() => setImageUrl('')}
                          className="absolute inset-0 bg-black/55 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity text-white text-xs font-bold cursor-pointer"
                        >
                          Remover
                        </button>
                      </div>
                    ) : (
                      <div className="h-16 w-16 rounded-2xl border-2 border-dashed border-slate-300 flex items-center justify-center text-slate-400 text-2xl">
                        🖼️
                      </div>
                    )}
                    <label className={`bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold py-2 px-4 rounded-xl shadow-sm transition-colors flex items-center space-x-1.5 ${compressing ? 'opacity-50 cursor-not-allowed pointer-events-none' : 'cursor-pointer'}`}>
                      <span>{compressing ? 'A processar imagem...' : 'Selecionar da Galeria'}</span>
                      <input 
                        type="file" 
                        accept="image/*" 
                        onChange={handleImageFileChange} 
                        className="hidden" 
                        disabled={compressing}
                      />
                    </label>
                    <p className="text-[10px] text-slate-400 text-center">
                      Suporta PNG, JPG. Máx: 50 MB. Recomenda-se formato quadrado.
                    </p>
                  </div>
                )}
              </div>

              {/* Available toggle */}
              <div className="flex items-center justify-between p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                <div>
                  <span className="font-semibold text-sm block text-slate-800">Disponibilidade do Produto</span>
                  <span className="text-xs text-slate-500">Se desativado, o prato aparecerá como 'Esgotado' para o cliente.</span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsAvailable(!isAvailable)}
                  className={`w-12 h-6.5 rounded-full p-1 transition-colors duration-200 focus:outline-none cursor-pointer ${
                    isAvailable ? 'bg-amber-500' : 'bg-slate-300'
                  }`}
                >
                  <div className={`bg-white w-4.5 h-4.5 rounded-full shadow-md transform duration-200 ease-in-out ${
                    isAvailable ? 'translate-x-5.5' : 'translate-x-0'
                  }`} />
                </button>
              </div>

              {/* Footer Save buttons */}
              <div className="pt-4 border-t border-slate-200 flex justify-end space-x-3 bg-slate-50 -mx-6 -mb-6 p-6">
                <button
                  type="button"
                  onClick={() => {
                    setIsAdding(false);
                    setEditingItem(null);
                  }}
                  className="py-3 px-5 border border-slate-300 bg-white hover:bg-slate-100 rounded-xl text-sm font-semibold text-slate-700 transition-colors cursor-pointer shadow-sm"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="py-3 px-5 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-sm font-semibold transition-colors flex items-center space-x-2 shadow-md shadow-amber-500/10 cursor-pointer disabled:opacity-55 disabled:cursor-not-allowed"
                >
                  {loading ? (
                    <span>A guardar...</span>
                  ) : (
                    <>
                      <Check className="h-4 w-4" />
                      <span>{editingItem ? 'Guardar Alterações' : 'Adicionar Prato'}</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
