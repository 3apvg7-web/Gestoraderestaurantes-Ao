import React, { useState, useEffect } from 'react';
import { User } from 'firebase/auth';
import { Restaurant, MenuItem, Order, PLAN_DETAILS, PlanType } from '../types';
import { 
  updateRestaurantProfile, 
  activateRestaurantPlan, 
  requestRestaurantPlan,
  approveRestaurantPlan,
  rejectRestaurantPlan,
  getAllRestaurants,
  listenToOrders, 
  listenToMenuItems 
} from '../utils/db';
import { compressImage } from '../utils/imageCompressor';
import { 
  LayoutDashboard, 
  ShoppingBag, 
  Utensils, 
  CreditCard, 
  Settings as SettingsIcon,
  Copy, 
  Check, 
  ExternalLink, 
  TrendingUp, 
  Clock, 
  ShieldAlert, 
  Phone,
  Sparkles,
  Smartphone,
  Loader2
} from 'lucide-react';

import MenuEditor from './MenuEditor';
import OrderManager from './OrderManager';
import MulticaixaSimulator from './MulticaixaSimulator';

interface AdminDashboardProps {
  user: User;
  restaurant: Restaurant;
  onUpdateRestaurant: (updated: Restaurant) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isAdminGod?: boolean;
}

export default function AdminDashboard({ user, restaurant, onUpdateRestaurant, activeTab, setActiveTab, isAdminGod }: AdminDashboardProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [copied, setCopied] = useState(false);

  // Settings state
  const [restName, setRestName] = useState(restaurant.name);
  const [restDesc, setRestDesc] = useState(restaurant.description);
  const [restSupport, setRestSupport] = useState(restaurant.supportPhone);
  const [restLogo, setRestLogo] = useState(restaurant.logoUrl);
  const [restLogoType, setRestLogoType] = useState<'emoji' | 'gallery'>(() => {
    const isCustom = restaurant.logoUrl && (restaurant.logoUrl.startsWith('data:') || restaurant.logoUrl.startsWith('http://') || restaurant.logoUrl.startsWith('https://'));
    return isCustom ? 'gallery' : 'emoji';
  });
  const [saveLoading, setSaveLoading] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [logoCompressing, setLogoCompressing] = useState(false);

  // Sync state if restaurant changes
  useEffect(() => {
    setRestName(restaurant.name);
    setRestDesc(restaurant.description);
    setRestSupport(restaurant.supportPhone);
    setRestLogo(restaurant.logoUrl);
    const isCustom = restaurant.logoUrl && (restaurant.logoUrl.startsWith('data:') || restaurant.logoUrl.startsWith('http://') || restaurant.logoUrl.startsWith('https://'));
    setRestLogoType(isCustom ? 'gallery' : 'emoji');
  }, [restaurant]);

  const handleLogoFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 50 * 1024 * 1024) {
        alert("A imagem selecionada é muito pesada! Por favor, escolha uma imagem com menos de 50 MB.");
        return;
      }
      setLogoCompressing(true);
      try {
        const compressedBase64 = await compressImage(file);
        setRestLogo(compressedBase64);
      } catch (err) {
        console.error("Erro ao processar imagem:", err);
        alert("Ocorreu um erro ao processar a imagem. Por favor, tente com outro arquivo.");
      } finally {
        setLogoCompressing(false);
      }
    }
  };

  // Multicaixa Simulator trigger
  const [selectedPlanToPay, setSelectedPlanToPay] = useState<typeof PLAN_DETAILS[PlanType] | null>(null);

  // Super Admin state for site owner Nazael
  const [simulateSuperAdmin, setSimulateSuperAdmin] = useState(() => {
    return localStorage.getItem('admin_god_active') === 'true';
  });
  const [allRestaurants, setAllRestaurants] = useState<Restaurant[]>([]);
  const [loadingAllRest, setLoadingAllRest] = useState(false);

  const isSuperAdmin = user.email?.toLowerCase() === atob('ZGluaXpuYXphZWxAZ21haWwuY29t') || simulateSuperAdmin || isAdminGod;

  useEffect(() => {
    // Listen to orders in real-time
    const unsubscribeOrders = listenToOrders(restaurant.id, (loadedOrders) => {
      setOrders(loadedOrders);
    });

    // Listen to menu items in real-time
    const unsubscribeMenu = listenToMenuItems(restaurant.id, (loadedItems) => {
      setMenuItems(loadedItems);
    });

    return () => {
      unsubscribeOrders();
      unsubscribeMenu();
    };
  }, [restaurant.id]);

  const handleCopyLink = () => {
    const customerLink = `${window.location.origin}/?restaurantId=${restaurant.id}`;
    navigator.clipboard.writeText(customerLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleOpenCustomerTab = () => {
    const customerLink = `${window.location.origin}/?restaurantId=${restaurant.id}`;
    window.open(customerLink, '_blank');
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaveLoading(true);
    setSaveSuccess(false);
    try {
      await updateRestaurantProfile(restaurant.id, {
        name: restName,
        description: restDesc,
        supportPhone: restSupport,
        logoUrl: restLogo,
      });
      // Update local state
      onUpdateRestaurant({
        ...restaurant,
        name: restName,
        description: restDesc,
        supportPhone: restSupport,
        logoUrl: restLogo,
      });
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err) {
      console.error('Error saving settings:', err);
    } finally {
      setSaveLoading(false);
    }
  };

  const handlePaymentSuccess = async (planId: PlanType, phoneNumber: string) => {
    try {
      await requestRestaurantPlan(restaurant.id, planId, phoneNumber);
      
      // Update local state
      onUpdateRestaurant({
        ...restaurant,
        planStatus: 'pending_approval',
        requestedPlan: planId,
        paymentPhone: phoneNumber,
        paymentDate: new Date().toISOString(),
      });
      
      setSelectedPlanToPay(null);
      setActiveTab('painel');
    } catch (err) {
      console.error('Error requesting plan in DB:', err);
    }
  };

  useEffect(() => {
    if (isSuperAdmin && activeTab === 'admin_geral') {
      loadAllRestaurants();
    }
  }, [isSuperAdmin, activeTab]);

  const loadAllRestaurants = async () => {
    setLoadingAllRest(true);
    try {
      const list = await getAllRestaurants();
      setAllRestaurants(list);
    } catch (err) {
      console.error('Error loading all restaurants:', err);
    } finally {
      setLoadingAllRest(false);
    }
  };

  const handleApprovePlan = async (targetRestId: string, plan: PlanType) => {
    try {
      await approveRestaurantPlan(targetRestId, plan);
      // Reload list
      await loadAllRestaurants();
      // If the currently logged in restaurant is the one approved, update local state
      if (targetRestId === restaurant.id) {
        onUpdateRestaurant({
          ...restaurant,
          activePlan: plan,
          planStatus: 'active',
          planStartDate: new Date().toISOString(),
          planEndDate: new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString(),
          requestedPlan: 'none',
          paymentPhone: '',
        });
      }
    } catch (err) {
      console.error('Error approving plan:', err);
    }
  };

  const handleRejectPlan = async (targetRestId: string) => {
    try {
      await rejectRestaurantPlan(targetRestId);
      // Reload list
      await loadAllRestaurants();
      // If the currently logged in restaurant is the one rejected, update local state
      if (targetRestId === restaurant.id) {
        onUpdateRestaurant({
          ...restaurant,
          planStatus: 'none',
          requestedPlan: 'none',
          paymentPhone: '',
        });
      }
    } catch (err) {
      console.error('Error rejecting plan:', err);
    }
  };

  // Stats summaries
  const pendingCount = orders.filter(o => o.status === 'pending').length;
  const preparingCount = orders.filter(o => o.status === 'preparing').length;
  const readyCount = orders.filter(o => o.status === 'ready').length;
  const completedOrders = orders.filter(o => o.status === 'delivered');
  const totalRevenue = completedOrders.reduce((sum, current) => sum + current.totalPrice, 0);

  const getDaysRemaining = () => {
    if (restaurant.planStatus !== 'active' || !restaurant.planEndDate) return 0;
    const diffTime = new Date(restaurant.planEndDate).getTime() - new Date().getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 0;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6">
      {/* Tab Selectors: Navigation Rails for Desktop and Bottom-nav for Mobile */}
      <div className="flex flex-col md:flex-row gap-6">
        
        {/* Desktop Sidebar menu - Deep Slate Visual Anchor */}
        <aside className="hidden md:flex flex-col w-64 shrink-0 bg-[#0f172a] text-white border border-slate-800 rounded-2xl p-4 space-y-2 h-fit sticky top-24 shadow-md">
          <div className="p-3 mb-2 border-b border-slate-800/60">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Navegação Administrativa</span>
          </div>
          {(() => {
            const tabs = [
              { id: 'painel', label: 'Painel Geral', icon: LayoutDashboard },
              { id: 'pedidos', label: 'Pedidos Ativos', icon: ShoppingBag, badge: pendingCount > 0 ? pendingCount : undefined },
              { id: 'cardapio', label: 'Editar Cardápio', icon: Utensils },
              { id: 'assinatura', label: 'Planos & Assinaturas', icon: CreditCard },
              { id: 'configuracoes', label: 'Configurações', icon: SettingsIcon },
            ];
            if (isSuperAdmin) {
              tabs.push({ id: 'admin_geral', label: 'Painel Nazael (Dono)', icon: ShieldAlert });
            }
            return tabs.map(tab => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full py-3 px-4 rounded-xl text-sm font-semibold flex items-center justify-between transition-all cursor-pointer ${
                    activeTab === tab.id 
                      ? 'bg-amber-500 text-white shadow-md shadow-amber-500/10 font-bold' 
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <Icon className="h-4.5 w-4.5" />
                    <span>{tab.label}</span>
                  </div>
                  {tab.badge && (
                    <span className="bg-red-500 text-white text-[10px] font-black h-5 w-5 rounded-full flex items-center justify-center animate-pulse">
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            });
          })()}

          {/* Simulate Super Admin Toggle for testing */}
          <div className="pt-4 mt-6 border-t border-slate-800/80 space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block px-2">Acesso Especial</span>
            <button
              id="btn-simulate-admin"
              onClick={() => {
                if (simulateSuperAdmin) {
                  setSimulateSuperAdmin(false);
                  localStorage.removeItem('admin_god_active');
                  if (activeTab === 'admin_geral') setActiveTab('painel');
                } else {
                  const passcode = prompt("Introduza o código de acesso especial Admin God:");
                  if (passcode === "939648067Dinizfilipe58") {
                    setSimulateSuperAdmin(true);
                    localStorage.setItem('admin_god_active', 'true');
                    alert("Acesso de Admin God ativado com sucesso! Seja bem-vindo, Nazael!");
                  } else if (passcode !== null) {
                    alert("Código de acesso especial incorreto!");
                  }
                }
              }}
              className={`w-full py-2 px-3 rounded-lg text-xs font-mono transition-colors cursor-pointer text-left flex items-center justify-between ${
                simulateSuperAdmin 
                  ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30' 
                  : 'bg-slate-800/40 text-slate-500 hover:text-slate-400 border border-transparent'
              }`}
            >
              <span>Acesso Admin God</span>
              <span className={`h-2 w-2 rounded-full ${simulateSuperAdmin ? 'bg-emerald-400 animate-pulse' : 'bg-slate-600'}`} />
            </button>
          </div>
        </aside>

        {/* Mobile top-rail navigator */}
        <div className="md:hidden flex flex-col space-y-2 pb-3 border-b border-slate-200">
          <div className="flex items-center space-x-1 overflow-x-auto scrollbar-none">
            {(() => {
              const tabs = [
                { id: 'painel', label: 'Painel', icon: LayoutDashboard },
                { id: 'pedidos', label: 'Pedidos', icon: ShoppingBag, badge: pendingCount > 0 ? pendingCount : undefined },
                { id: 'cardapio', label: 'Cardápio', icon: Utensils },
                { id: 'assinatura', label: 'Planos', icon: CreditCard },
                { id: 'configuracoes', label: 'Ajustes', icon: SettingsIcon },
              ];
              if (isSuperAdmin) {
                tabs.push({ id: 'admin_geral', label: 'Nazael', icon: ShieldAlert });
              }
              return tabs.map(tab => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`py-2 px-3.5 rounded-xl text-xs font-semibold shrink-0 flex items-center space-x-1.5 transition-all cursor-pointer ${
                      activeTab === tab.id 
                        ? 'bg-amber-500 text-white font-bold shadow-sm shadow-amber-500/10' 
                        : 'bg-white border border-slate-200 text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    <Icon className="h-3.5 w-3.5" />
                    <span>{tab.label}</span>
                    {tab.badge && (
                      <span className="bg-red-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded-full">
                        {tab.badge}
                      </span>
                    )}
                  </button>
                );
              });
            })()}
          </div>
          
          <button
            id="btn-simulate-admin-mobile"
            onClick={() => {
              if (simulateSuperAdmin) {
                setSimulateSuperAdmin(false);
                localStorage.removeItem('admin_god_active');
                if (activeTab === 'admin_geral') setActiveTab('painel');
              } else {
                const passcode = prompt("Introduza o código de acesso especial Admin God:");
                if (passcode === "939648067Dinizfilipe58") {
                  setSimulateSuperAdmin(true);
                  localStorage.setItem('admin_god_active', 'true');
                  alert("Acesso de Admin God ativado com sucesso! Seja bem-vindo, Nazael!");
                } else if (passcode !== null) {
                  alert("Código de acesso especial incorreto!");
                }
              }
            }}
            className={`w-full py-2 px-3 rounded-xl text-[11px] font-mono transition-colors cursor-pointer flex items-center justify-between ${
              simulateSuperAdmin 
                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                : 'bg-slate-100 text-slate-500 border border-slate-200'
            }`}
          >
            <span className="font-semibold">Acesso Admin God</span>
            <span className={`h-2 w-2 rounded-full ${simulateSuperAdmin ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'}`} />
          </button>
        </div>

        {/* Main tabs content panel */}
        <main className="flex-1 min-w-0">
          
          {/* PAINEL GERAL (DASHBOARD) TAB */}
          {activeTab === 'painel' && (
            <div className="space-y-6">
              {/* Active Plan Card - Premium Slate Block visual anchor */}
              <div className="p-6 rounded-2xl bg-[#0f172a] text-white border border-slate-800 relative overflow-hidden shadow-md">
                <div className="absolute right-0 top-0 h-40 w-40 bg-indigo-500/5 rounded-full blur-3xl" />
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
                  <div className="space-y-2">
                    <span className="text-[10px] uppercase font-bold text-slate-300 bg-slate-800 px-2 py-1 rounded">Assinatura Ativa</span>
                    <h2 className="font-display font-extrabold text-2xl text-white flex items-center gap-2">
                      {restaurant.planStatus === 'active' ? (
                        <>
                          {PLAN_DETAILS[restaurant.activePlan || 'none']?.name}
                          <span className="text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded px-2 py-0.5">Ativo</span>
                        </>
                      ) : restaurant.planStatus === 'pending_approval' ? (
                        <>
                          {PLAN_DETAILS[restaurant.requestedPlan || 'none']?.name}
                          <span className="text-xs text-sky-400 bg-sky-500/10 border border-sky-500/20 rounded px-2 py-0.5 animate-pulse">Aguardando Liberação ⏳</span>
                        </>
                      ) : (
                        <>
                          Sem Plano Ativo
                          <span className="text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded px-2 py-0.5">Inativo ⚠️</span>
                        </>
                      )}
                    </h2>
                    <p className="text-slate-300 text-sm max-w-xl">
                      {restaurant.planStatus === 'active' 
                        ? `A sua assinatura atual de ${PLAN_DETAILS[restaurant.activePlan]?.name} permite o uso de ${PLAN_DETAILS[restaurant.activePlan]?.servicePercent}% dos recursos totais de gerenciamento.`
                        : restaurant.planStatus === 'pending_approval'
                        ? `O seu pedido de ativação do ${PLAN_DETAILS[restaurant.requestedPlan || 'none']?.name} está em análise. O plano será liberado assim que o proprietário Nazael Diniz Alves Primo Giblin confirmar o pagamento via telemóvel ${restaurant.paymentPhone}.`
                        : 'Você precisa escolher e ativar um plano de assinatura para habilitar o cardápio e receber pedidos de clientes.'}
                    </p>
                  </div>

                  <div className="shrink-0 flex flex-col items-start md:items-end gap-2 bg-slate-950/40 p-4 rounded-xl border border-slate-800/80 min-w-[180px]">
                    <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Expiração do Plano</div>
                    <div className="flex items-center space-x-2">
                      <Clock className="h-5 w-5 text-amber-500" />
                      <span className="text-xl font-mono font-bold text-white">
                        {restaurant.planStatus === 'active' 
                          ? `${getDaysRemaining()} Dias` 
                          : restaurant.planStatus === 'pending_approval'
                          ? 'Pendente'
                          : 'Expirado'}
                      </span>
                    </div>
                    {restaurant.planStatus === 'pending_approval' ? (
                      <span className="text-[10px] text-amber-500 font-semibold mt-1.5 flex items-center gap-1">
                        <span className="h-1.5 w-1.5 rounded-full bg-amber-500 animate-ping" />
                        Sob Análise de Nazael
                      </span>
                    ) : restaurant.planStatus !== 'active' ? (
                      <button
                        onClick={() => setActiveTab('assinatura')}
                        className="text-xs font-semibold text-amber-500 hover:underline mt-1.5"
                      >
                        Pagar plano agora &rarr;
                      </button>
                    ) : (
                      <span className="text-[10px] text-slate-400 font-mono">Válido até: {new Date(restaurant.planEndDate).toLocaleDateString('pt-PT')}</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Stats Cards - Geometric White Panels */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: 'Faturamento Recebido', value: `${totalRevenue.toLocaleString('pt-PT')} KZ`, icon: TrendingUp, color: 'text-emerald-500 bg-emerald-50' },
                  { label: 'Pedidos Pendentes', value: pendingCount, icon: Clock, color: 'text-amber-500 bg-amber-50' },
                  { label: 'Pedidos Na Cozinha', value: preparingCount, icon: Utensils, color: 'text-indigo-500 bg-indigo-50' },
                  { label: 'Cardápio Ativo', value: `${menuItems.length} Itens`, icon: ShoppingBag, color: 'text-sky-500 bg-sky-50' },
                ].map((stat, idx) => {
                  const Icon = stat.icon;
                  return (
                    <div key={idx} className="p-4 bg-white border border-slate-200 rounded-2xl space-y-2 shadow-sm flex flex-col justify-between">
                      <div className="flex justify-between items-center text-slate-400">
                        <span className="text-[10px] font-bold tracking-tight leading-none uppercase text-slate-500">{stat.label}</span>
                        <div className={`p-1.5 rounded-lg ${stat.color.split(' ')[1]}`}>
                          <Icon className={`h-4 w-4 ${stat.color.split(' ')[0]}`} />
                        </div>
                      </div>
                      <div className="font-display font-bold text-lg sm:text-xl text-slate-800">{stat.value}</div>
                    </div>
                  );
                })}
              </div>
              {/* Customer Link Generator Card */}
              <div className="p-6 rounded-2xl bg-white border border-slate-200 space-y-4 shadow-sm">
                <div className="space-y-1">
                  <h3 className="font-display font-bold text-lg text-slate-800">Link de Autoatendimento para Clientes</h3>
                  <p className="text-slate-500 text-sm">
                    Partilhe este link com os clientes (redes sociais, WhatsApp, QR code impresso nas mesas) para que possam abrir o cardápio e fazer pedidos diretos na mesa ou delivery!
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                  <span className="font-mono text-xs text-slate-600 px-3 truncate flex-1 leading-normal py-2 select-all">
                    {window.location.origin}/?restaurantId={restaurant.id}
                  </span>
                  <div className="flex gap-2">
                    <button
                      id="btn-copy-customer-link"
                      onClick={handleCopyLink}
                      className="flex-1 sm:flex-initial bg-slate-100 hover:bg-slate-200 text-slate-700 py-2.5 px-4 rounded-lg text-xs font-semibold flex items-center justify-center space-x-1.5 transition-all cursor-pointer border border-slate-300/60"
                    >
                      {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5 text-slate-500" />}
                      <span>{copied ? 'Copiado!' : 'Copiar Link'}</span>
                    </button>
                    <button
                      id="btn-open-customer-link"
                      onClick={handleOpenCustomerTab}
                      className="flex-1 sm:flex-initial bg-amber-500 hover:bg-amber-600 text-white py-2.5 px-4 rounded-lg text-xs font-semibold flex items-center justify-center space-x-1.5 transition-all cursor-pointer shadow-md shadow-amber-500/15"
                    >
                      <ExternalLink className="h-3.5 w-3.5" />
                      <span>Abrir como Cliente</span>
                    </button>
                  </div>
                </div>

                <div className="p-4 bg-amber-500/5 border border-amber-500/10 rounded-xl flex items-start gap-2.5 text-amber-800 text-xs">
                  <Sparkles className="h-4.5 w-4.5 text-amber-500 shrink-0 mt-0.5" />
                  <span>
                    <strong>Dica de Integração:</strong> Salve o link em geradores de QR Code online e cole nas mesas do seu restaurante. O cliente só precisa apontar a câmara do telemóvel para encomendar na hora!
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* PEDIDOS TAB */}
          {activeTab === 'pedidos' && (
            <OrderManager restaurant={restaurant} orders={orders} />
          )}

          {/* CARDÁPIO TAB */}
          {activeTab === 'cardapio' && (
            <MenuEditor 
              restaurant={restaurant} 
              menuItems={menuItems} 
              onNavigateToSubscription={() => setActiveTab('assinatura')} 
            />
          )}

          {/* ASSINATURA (PRICING & SIMULATOR) TAB */}
          {activeTab === 'assinatura' && (
            <div className="space-y-6">
              <div>
                <h2 className="font-display font-bold text-2xl text-slate-800">Planos de Assinatura</h2>
                <p className="text-slate-500 text-sm mt-1">
                  Selecione o plano ideal para as dimensões do seu restaurante. Pague via Multicaixa Express.
                </p>
              </div>

              {/* Grid of pricing cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[
                  PLAN_DETAILS.bala,
                  PLAN_DETAILS.plus_bala,
                  PLAN_DETAILS.gold,
                ].map(p => {
                  const isActive = restaurant.activePlan === p.id && restaurant.planStatus === 'active';
                  return (
                    <div 
                      key={p.id}
                      className={`p-6 rounded-2xl bg-white border flex flex-col justify-between relative overflow-hidden shadow-sm transition-all ${
                        isActive 
                          ? 'border-amber-500 shadow-lg shadow-amber-500/5 bg-amber-500/5 scale-102' 
                          : 'border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      {isActive && (
                        <span className="absolute top-3.5 right-3.5 bg-amber-500 text-white text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full shadow-sm">
                          Seu Plano Ativo
                        </span>
                      )}

                      <div className="space-y-4">
                        <div>
                          <h3 className="font-display font-bold text-lg text-slate-800">{p.name}</h3>
                          <p className="text-slate-500 text-xs mt-1">Limite operacional: {p.servicePercent}% dos recursos</p>
                        </div>

                        <div className="flex items-baseline space-x-1 border-b border-slate-200 pb-4">
                          <span className="text-2xl font-mono font-bold text-slate-800">{p.priceFormatted}</span>
                          <span className="text-slate-400 text-xs font-semibold">/ mês</span>
                        </div>

                        {/* Feature bullets */}
                        <ul className="space-y-2.5 text-xs text-slate-600">
                          {p.features.map((feat, fIdx) => (
                            <li key={fIdx} className="flex items-start space-x-2">
                              <Check className="h-3.5 w-3.5 text-emerald-500 shrink-0 mt-0.5" />
                              <span>{feat}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="pt-6">
                        <button
                          id={`btn-select-plan-${p.id}`}
                          onClick={() => setSelectedPlanToPay(p)}
                          className={`w-full py-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                            isActive
                              ? 'bg-amber-500 text-white hover:bg-amber-600 shadow-md shadow-amber-500/10'
                              : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-300'
                          }`}
                        >
                          {isActive ? 'Renovar Plano Ativo' : `Contratar ${p.name}`}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Support helpline card */}
              <div className="p-5 rounded-2xl bg-white border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
                <div className="flex items-start space-x-3.5 text-left">
                  <div className="p-2 bg-amber-50 rounded-xl text-amber-500 shrink-0 mt-0.5">
                    <Phone className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm text-slate-800">Dúvidas ou Erros na Ativação?</h4>
                    <p className="text-xs text-slate-500 mt-1">
                      Entre em contacto direto com o suporte financeiro e técnico de Angola pelo número <strong>923002202</strong>. Estamos disponíveis por chamadas ou WhatsApp para ativações manuais.
                    </p>
                  </div>
                </div>
                <a
                  href="tel:923002202"
                  className="bg-slate-50 hover:bg-slate-100 border border-slate-300 text-slate-700 font-semibold py-2.5 px-4.5 rounded-xl text-xs shrink-0 flex items-center space-x-1.5 transition-colors cursor-pointer"
                >
                  <Phone className="h-3.5 w-3.5 text-amber-500" />
                  <span>Ligar 923 002 202</span>
                </a>
              </div>
            </div>
          )}

          {/* CONFIGURAÇÕES TAB */}
          {activeTab === 'configuracoes' && (
            <div className="space-y-6">
              <div>
                <h2 className="font-display font-bold text-2xl text-slate-800">Configurações do Restaurante</h2>
                <p className="text-slate-500 text-sm mt-1">
                  Personalize os dados de apresentação que os seus clientes visualizam ao abrir o link.
                </p>
              </div>

              <form onSubmit={handleSaveSettings} className="bg-white border border-slate-200 p-6 rounded-2xl space-y-4 shadow-sm">
                {saveSuccess && (
                  <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-1.5">
                    <Check className="h-4.5 w-4.5 text-emerald-500" />
                    <span>Configurações atualizadas com sucesso na base de dados!</span>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Restaurant Name */}
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                      Nome do Restaurante *
                    </label>
                    <input
                      type="text"
                      value={restName}
                      onChange={(e) => setRestName(e.target.value)}
                      placeholder="Ex: Pastelaria Luanda, Kikuia Chef"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 transition-all"
                      required
                    />
                  </div>

                  {/* Logo Emoji or Gallery Picker */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400">
                        Símbolo / Logo do Restaurante *
                      </label>
                      <div className="flex bg-slate-100 p-0.5 rounded-lg border border-slate-200">
                        <button
                          type="button"
                          onClick={() => {
                            setRestLogoType('emoji');
                            if (restLogo.startsWith('data:') || restLogo.startsWith('http')) {
                              setRestLogo('🍽️');
                            }
                          }}
                          className={`px-3 py-1 text-xs font-bold rounded-md transition-all cursor-pointer ${
                            restLogoType === 'emoji' 
                              ? 'bg-white text-slate-800 shadow-sm' 
                              : 'text-slate-500 hover:text-slate-700'
                          }`}
                        >
                          Emoji
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setRestLogoType('gallery');
                            if (!restLogo.startsWith('data:') && !restLogo.startsWith('http')) {
                              setRestLogo('');
                            }
                          }}
                          className={`px-3 py-1 text-xs font-bold rounded-md transition-all cursor-pointer ${
                            restLogoType === 'gallery' 
                              ? 'bg-white text-slate-800 shadow-sm' 
                              : 'text-slate-500 hover:text-slate-700'
                          }`}
                        >
                          Galeria 📸
                        </button>
                      </div>
                    </div>

                    {restLogoType === 'emoji' ? (
                      <select
                        value={restLogo}
                        onChange={(e) => setRestLogo(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-sm text-slate-800 focus:outline-none focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 transition-all cursor-pointer"
                      >
                        {['🍽️', '🍔', '🍕', '🍗', '🍜', '🍱', '🥐', '🥩', '🍰', '🧁', '🍹', '🍺', '☕'].map(emoji => (
                          <option key={emoji} value={emoji}>{emoji} - Ícone</option>
                        ))}
                      </select>
                    ) : (
                      <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex flex-col items-center justify-center gap-3">
                        {restLogo && (restLogo.startsWith('data:') || restLogo.startsWith('http')) ? (
                          <div className="relative group w-16 h-16 rounded-2xl overflow-hidden border border-slate-300 shadow-sm">
                            <img 
                              src={restLogo} 
                              alt="Previsualização Logo" 
                              className="w-full h-full object-cover"
                            />
                            <button
                              type="button"
                              onClick={() => setRestLogo('')}
                              className="absolute inset-0 bg-black/55 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity text-white text-[10px] font-bold cursor-pointer"
                            >
                              Remover
                            </button>
                          </div>
                        ) : (
                          <div className="h-12 w-12 rounded-xl border-2 border-dashed border-slate-300 flex items-center justify-center text-slate-400 text-xl">
                            🖼️
                          </div>
                        )}
                        <label className={`bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold py-2 px-4 rounded-xl shadow-sm transition-colors flex items-center space-x-1.5 ${logoCompressing ? 'opacity-50 cursor-not-allowed pointer-events-none' : 'cursor-pointer'}`}>
                          <span>{logoCompressing ? 'A processar imagem...' : 'Selecionar Logo da Galeria'}</span>
                          <input 
                            type="file" 
                            accept="image/*" 
                            onChange={handleLogoFileChange} 
                            className="hidden" 
                            disabled={logoCompressing}
                          />
                        </label>
                        <p className="text-[10px] text-slate-400 text-center">
                          Suporta PNG, JPG. Máx: 50 MB. Recomenda-se formato quadrado.
                        </p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Short Description */}
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                    Descrição Curta de Boas-vindas
                  </label>
                  <textarea
                    value={restDesc}
                    onChange={(e) => setRestDesc(e.target.value)}
                    placeholder="Escreva uma mensagem que seus clientes verão no topo do cardápio digital."
                    rows={3}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 transition-all"
                  />
                </div>

                {/* Customer support phone line override */}
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                    Telefone Oficial de Apoio ao Cliente (9 dígitos) *
                  </label>
                  <input
                    type="tel"
                    value={restSupport}
                    onChange={(e) => setRestSupport(e.target.value.replace(/\D/g, '').slice(0, 9))}
                    placeholder="Padrão: 923002202"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-sm text-slate-800 font-mono placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 transition-all"
                    required
                  />
                  <p className="text-[10px] text-slate-500 mt-1">Este número será mostrado para os seus clientes caso necessitem de suporte.</p>
                </div>

                <div className="pt-4 border-t border-slate-200 flex justify-end">
                  <button
                    id="btn-save-settings"
                    type="submit"
                    disabled={saveLoading}
                    className="py-3 px-6 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-amber-500/10 cursor-pointer disabled:opacity-50"
                  >
                    {saveLoading ? 'A guardar alterações...' : 'Guardar Alterações'}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* PAINEL ADMINISTRADOR GERAL (NAZAEL) */}
          {activeTab === 'admin_geral' && isSuperAdmin && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                  <h2 className="font-display font-bold text-2xl text-slate-800 flex items-center gap-2">
                    <ShieldAlert className="h-6 w-6 text-amber-500" />
                    Painel Administrativo do Site
                  </h2>
                  <p className="text-slate-500 text-sm mt-1">
                    Gerenciamento global de restaurantes e liberação manual de planos de assinatura por <strong>Nazael Diniz Alves Primo Giblin</strong>.
                  </p>
                </div>
                <button
                  id="btn-refresh-admin-restaurants"
                  onClick={loadAllRestaurants}
                  disabled={loadingAllRest}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 py-2 px-4 rounded-xl text-xs font-semibold border border-slate-300/60 shrink-0 self-start sm:self-center transition-colors cursor-pointer"
                >
                  {loadingAllRest ? 'Atualizando...' : 'Atualizar Lista'}
                </button>
              </div>

              {/* Stats of system */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-white p-4 rounded-xl border border-slate-200">
                  <span className="text-[10px] uppercase font-bold text-slate-500 block">Total de Restaurantes</span>
                  <span className="text-2xl font-bold text-slate-800 mt-1 block">{allRestaurants.length}</span>
                </div>
                <div className="bg-white p-4 rounded-xl border border-slate-200">
                  <span className="text-[10px] uppercase font-bold text-slate-500 block">Planos Ativos</span>
                  <span className="text-2xl font-bold text-emerald-600 mt-1 block">
                    {allRestaurants.filter(r => r.planStatus === 'active').length}
                  </span>
                </div>
                <div className="bg-white p-4 rounded-xl border border-slate-200">
                  <span className={`text-[10px] uppercase font-bold block ${allRestaurants.filter(r => r.planStatus === 'pending_approval').length > 0 ? 'text-amber-500' : 'text-slate-500'}`}>Solicitações Pendentes</span>
                  <span className={`text-2xl font-bold mt-1 block ${allRestaurants.filter(r => r.planStatus === 'pending_approval').length > 0 ? 'text-amber-500 animate-pulse' : 'text-slate-500'}`}>
                    {allRestaurants.filter(r => r.planStatus === 'pending_approval').length}
                  </span>
                </div>
              </div>

              {/* Pending Approvals Section */}
              <div className="space-y-3">
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500">Solicitações de Ativação</h3>
                {loadingAllRest ? (
                  <div className="bg-white p-12 text-center rounded-2xl border border-slate-200 text-slate-400 text-xs flex flex-col items-center justify-center space-y-2">
                    <Loader2 className="h-6 w-6 text-amber-500 animate-spin" />
                    <span>Carregando dados dos restaurantes...</span>
                  </div>
                ) : allRestaurants.filter(r => r.planStatus === 'pending_approval').length === 0 ? (
                  <div className="bg-white p-8 text-center rounded-2xl border border-slate-200 text-slate-400 text-xs">
                    Não existem solicitações de ativação de plano pendentes de validação no momento.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 gap-4">
                    {allRestaurants
                      .filter(r => r.planStatus === 'pending_approval')
                      .map(rest => (
                        <div key={rest.id} className="bg-white border-2 border-amber-500/40 p-5 rounded-2xl shadow-sm flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                          <div className="space-y-2 text-left">
                            <div className="flex items-center gap-2">
                              {rest.logoUrl && (rest.logoUrl.startsWith('data:') || rest.logoUrl.startsWith('http')) ? (
                                <img src={rest.logoUrl} alt={rest.name} className="w-8 h-8 object-cover rounded-xl border border-slate-200" />
                              ) : (
                                <span className="text-xl">{rest.logoUrl || '🍽️'}</span>
                              )}
                              <h4 className="font-display font-bold text-base text-slate-800">{rest.name}</h4>
                              <span className="text-[10px] bg-amber-500/10 text-amber-800 px-2 py-0.5 rounded-full font-bold">Solicitação de Plano</span>
                            </div>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1 text-xs text-slate-500 font-mono">
                              <p>Proprietário: <strong className="text-slate-700">{rest.ownerEmail}</strong></p>
                              <p>Telemóvel MC: <strong className="text-amber-600 font-bold">{rest.paymentPhone || 'Não informado'}</strong></p>
                              <p>Plano Solicitado: <strong className="text-indigo-600 font-bold uppercase">{PLAN_DETAILS[rest.requestedPlan || 'none']?.name} ({PLAN_DETAILS[rest.requestedPlan || 'none']?.priceFormatted})</strong></p>
                              <p>Data do Pedido: <strong className="text-slate-700">{rest.paymentDate ? new Date(rest.paymentDate).toLocaleString('pt-PT') : 'N/D'}</strong></p>
                            </div>
                          </div>
                          
                          <div className="flex gap-2.5 shrink-0">
                            <button
                              id={`btn-reject-plan-${rest.id}`}
                              onClick={() => handleRejectPlan(rest.id)}
                              className="px-4 py-2.5 bg-red-50 hover:bg-red-100 text-red-600 border border-red-200 hover:border-red-300 rounded-xl text-xs font-bold transition-all cursor-pointer"
                            >
                              Recusar
                            </button>
                            <button
                              id={`btn-approve-plan-${rest.id}`}
                              onClick={() => handleApprovePlan(rest.id, rest.requestedPlan || 'none')}
                              className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-500/15 transition-all cursor-pointer flex items-center space-x-1"
                            >
                              <Check className="h-4 w-4" />
                              <span>Confirmar & Liberar</span>
                            </button>
                          </div>
                        </div>
                      ))}
                  </div>
                )}
              </div>

              {/* All Restaurants Registry Section */}
              <div className="space-y-3 pt-4">
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500">Histórico & Lista de Clientes Ativos</h3>
                <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider">
                          <th className="p-4">Restaurante</th>
                          <th className="p-4">Proprietário</th>
                          <th className="p-4">Plano</th>
                          <th className="p-4">Status Assinatura</th>
                          <th className="p-4">Expiração</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {allRestaurants.map(rest => (
                          <tr key={rest.id} className="hover:bg-slate-50/50">
                            <td className="p-4 font-semibold text-slate-800 flex items-center space-x-2">
                              {rest.logoUrl && (rest.logoUrl.startsWith('data:') || rest.logoUrl.startsWith('http')) ? (
                                <img src={rest.logoUrl} alt={rest.name} className="w-6 h-6 object-cover rounded border border-slate-200 shrink-0" />
                              ) : (
                                <span>{rest.logoUrl || '🍽️'}</span>
                              )}
                              <span>{rest.name}</span>
                            </td>
                            <td className="p-4 text-slate-500 font-mono">{rest.ownerEmail}</td>
                            <td className="p-4 font-mono font-bold text-slate-700 uppercase">
                              {rest.planStatus === 'pending_approval' 
                                ? PLAN_DETAILS[rest.requestedPlan || 'none']?.name + ' (Pendente)'
                                : PLAN_DETAILS[rest.activePlan || 'none']?.name}
                            </td>
                            <td className="p-4">
                              {rest.planStatus === 'active' ? (
                                <span className="bg-emerald-50 border border-emerald-200 text-emerald-700 px-2 py-0.5 rounded font-bold">Ativo</span>
                              ) : rest.planStatus === 'pending_approval' ? (
                                <span className="bg-amber-50 border border-amber-200 text-amber-700 px-2 py-0.5 rounded font-bold animate-pulse">Pendente</span>
                              ) : rest.planStatus === 'expired' ? (
                                <span className="bg-red-50 border border-red-200 text-red-700 px-2 py-0.5 rounded font-bold">Expirado</span>
                              ) : (
                                <span className="bg-slate-100 border border-slate-200 text-slate-500 px-2 py-0.5 rounded">Nenhum</span>
                              )}
                            </td>
                            <td className="p-4 text-slate-500 font-mono">
                              {rest.planStatus === 'active' && rest.planEndDate
                                ? new Date(rest.planEndDate).toLocaleDateString('pt-PT')
                                : '-'}
                            </td>
                          </tr>
                        ))}
                        {allRestaurants.length === 0 && (
                          <tr>
                            <td colSpan={5} className="p-8 text-center text-slate-400">Nenhum restaurante cadastrado no sistema.</td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          )}

        </main>
      </div>

      {/* Multicaixa Payment Simulator Overlay */}
      {selectedPlanToPay && (
        <MulticaixaSimulator 
          plan={selectedPlanToPay} 
          onSuccess={handlePaymentSuccess} 
          onClose={() => setSelectedPlanToPay(null)} 
        />
      )}
    </div>
  );
}
