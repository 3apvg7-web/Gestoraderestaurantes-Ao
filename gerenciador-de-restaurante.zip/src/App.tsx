import React, { useState, useEffect } from 'react';
import { User, onAuthStateChanged } from 'firebase/auth';
import { auth, loginWithGoogle, logoutUser } from './firebase';
import { Restaurant, PLAN_DETAILS } from './types';
import { getRestaurantById, createRestaurantProfile } from './utils/db';

import Navbar from './components/Navbar';
import AdminDashboard from './components/AdminDashboard';
import ClientView from './components/ClientView';

import { 
  Utensils, 
  Smartphone, 
  Check, 
  Phone, 
  ShieldAlert, 
  Sparkles, 
  Plus, 
  Award, 
  Loader2, 
  HelpCircle,
  LayoutDashboard,
  ChefHat,
  Crown
} from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null);
  
  // Admin God authentication states
  const [isAdminGod, setIsAdminGod] = useState(() => localStorage.getItem('admin_god_active') === 'true');
  const [showGodModal, setShowGodModal] = useState(false);
  const [godPasscode, setGodPasscode] = useState('');
  const [godError, setGodError] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  
  // App routing/mode states
  const [loading, setLoading] = useState(true);
  const [clientMode, setClientMode] = useState(false);
  const [clientRestaurant, setClientRestaurant] = useState<Restaurant | null>(null);
  const [clientRestError, setClientRestError] = useState('');

  // Creation / Registration UI flow
  const [isRegistering, setIsRegistering] = useState(false);
  const [newRestName, setNewRestName] = useState('');
  const [registerLoading, setRegisterLoading] = useState(false);

  // Active Admin Tab state
  const [activeTab, setActiveTab] = useState('painel');

  // Detect URL parameter for customer client view
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const restIdParam = params.get('restaurantId');

    if (restIdParam) {
      setClientMode(true);
      
      // Load public restaurant metadata
      getRestaurantById(restIdParam)
        .then((profile) => {
          if (profile) {
            setClientRestaurant(profile);
          } else {
            setClientRestError('O restaurante solicitado não foi encontrado ou não está cadastrado na nossa plataforma.');
          }
          setLoading(false);
        })
        .catch((err) => {
          console.error(err);
          setClientRestError('Ocorreu um erro ao carregar os dados do restaurante. Por favor tente novamente mais tarde.');
          setLoading(false);
        });
    } else {
      setClientMode(false);
      
      // Auth state observer for Admin portal
      const unsubscribeAuth = onAuthStateChanged(auth, async (currentUser) => {
        setUser(currentUser);
        if (currentUser) {
          try {
            // Load their corresponding restaurant profile (ID matches UID)
            const profile = await getRestaurantById(currentUser.uid);
            if (profile) {
              setRestaurant(profile);
              setIsRegistering(false);
            } else {
              // They are authenticated but have no restaurant profile yet! Show register screen
              setIsRegistering(true);
            }
          } catch (err) {
            console.error('Error loading restaurant on login:', err);
          }
        } else {
          setRestaurant(null);
          setIsRegistering(false);
        }
        setLoading(false);
      });

      return () => unsubscribeAuth();
    }
  }, []);

  const handleGoogleLogin = async () => {
    setLoading(true);
    setAuthError(null);
    try {
      await loginWithGoogle();
    } catch (err: any) {
      console.error("Google login error caught in App.tsx:", err);
      const errCode = err?.code || "";
      const errMsg = err?.message || "";
      if (errCode === "auth/popup-closed-by-user" || errMsg.includes("popup-closed-by-user") || errMsg.includes("popup-blocked")) {
        setAuthError(
          "O login do Google foi bloqueado ou fechado pelo seu navegador. Como esta demonstração está a correr dentro de um Iframe (moldura de segurança), a comunicação do popup é frequentemente restringida. Por favor, clique no botão 'Abrir em Nova Aba ↗' no topo para entrar perfeitamente com a sua Conta Google!"
        );
      } else {
        setAuthError(errMsg || "Ocorreu um erro ao aceder com o Google. Experimente abrir em Nova Aba.");
      }
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    setLoading(true);
    try {
      await logoutUser();
      setRestaurant(null);
      setUser(null);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateRestaurant = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newRestName.trim()) return;

    setRegisterLoading(true);
    try {
      const profile = await createRestaurantProfile(user.uid, user.email || '', newRestName);
      setRestaurant(profile);
      setIsRegistering(false);
    } catch (err) {
      console.error('Error provisioning restaurant profile:', err);
    } finally {
      setRegisterLoading(false);
    }
  };

  const renderAdminGodBypass = () => {
    if (clientMode) return null;

    const handleGodLoginSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (godPasscode === '939648067Dinizfilipe58') {
        setIsAdminGod(true);
        localStorage.setItem('admin_god_active', 'true');
        setShowGodModal(false);
        setGodPasscode('');
        setGodError('');
        setActiveTab('admin_geral');
      } else {
        setGodError('Código de acesso especial incorreto!');
      }
    };

    const handleToggleGodMode = () => {
      if (isAdminGod) {
        setIsAdminGod(false);
        localStorage.removeItem('admin_god_active');
        setActiveTab('painel');
      } else {
        setShowGodModal(true);
      }
    };

    return (
      <>
        {/* Floating Crown Trigger Button */}
        <button
          onClick={handleToggleGodMode}
          className={`fixed bottom-4 right-4 z-50 p-3 rounded-full shadow-lg hover:scale-105 active:scale-95 transition-all cursor-pointer group flex items-center justify-center border ${
            isAdminGod 
              ? 'bg-amber-500 text-white border-amber-600 shadow-amber-500/20' 
              : 'bg-slate-900 text-amber-400 border-slate-800 shadow-slate-900/20'
          }`}
          title={isAdminGod ? "Admin God Ativo - Clique para Desativar" : "Acesso Especial Admin God"}
        >
          <Crown className={`h-5 w-5 ${isAdminGod ? 'animate-bounce' : 'animate-pulse group-hover:rotate-12 transition-transform'}`} />
        </button>

        {/* Admin God Password Modal */}
        {showGodModal && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl border border-slate-200 p-6 w-full max-w-sm shadow-xl space-y-4 relative">
              <div className="text-center space-y-2">
                <div className="h-12 w-12 bg-amber-500/10 text-amber-500 rounded-full flex items-center justify-center mx-auto text-xl font-bold border border-amber-500/20">
                  👑
                </div>
                <h3 className="font-display font-extrabold text-lg text-slate-900">Acesso Especial Admin God</h3>
                <p className="text-xs text-slate-500">
                  Introduza o código mestre para ativar o modo de liberação de planos e gerenciamento geral de restaurantes.
                </p>
              </div>

              <form onSubmit={handleGodLoginSubmit} className="space-y-3">
                <div>
                  <input
                    type="password"
                    value={godPasscode}
                    onChange={(e) => {
                      setGodPasscode(e.target.value);
                      setGodError('');
                    }}
                    placeholder="Código de Acesso"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-4 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:bg-white transition-all text-center font-mono tracking-widest"
                    autoFocus
                    required
                  />
                  {godError && (
                    <p className="text-red-500 text-[11px] font-semibold text-center mt-1.5">{godError}</p>
                  )}
                </div>

                <div className="flex gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setShowGodModal(false);
                      setGodPasscode('');
                      setGodError('');
                    }}
                    className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold shadow-sm shadow-amber-500/10 transition-colors cursor-pointer"
                  >
                    Ativar
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </>
    );
  };

  // --- RENDERS ---

  // Loading Screen
  if (loading) {
    return (
      <div className="min-h-screen bg-[#f8fafc] flex flex-col items-center justify-center text-slate-800 space-y-4">
        <Loader2 className="h-10 w-10 text-amber-500 animate-spin" />
        <p className="text-sm text-slate-500 font-medium">A carregar serviços...</p>
      </div>
    );
  }

  // CUSTOMER CLIENT MENU MODE
  if (clientMode) {
    if (clientRestError) {
      return (
        <div className="min-h-screen bg-[#f8fafc] text-slate-800 flex flex-col items-center justify-center p-4 text-center space-y-5">
          <div className="h-16 w-16 bg-red-500/10 border-2 border-red-500 text-red-500 rounded-full flex items-center justify-center animate-pulse">
            <ShieldAlert className="h-8 w-8" />
          </div>
          <div className="space-y-2 max-w-md">
            <h2 className="font-display font-extrabold text-2xl text-slate-900">Cardápio Indisponível</h2>
            <p className="text-slate-500 text-sm">
              {clientRestError}
            </p>
          </div>
          <div className="bg-white border border-slate-200 shadow-sm p-4 rounded-xl flex items-center space-x-3.5 text-left max-w-sm">
            <Phone className="h-5 w-5 text-amber-500 shrink-0" />
            <div>
              <span className="font-semibold block text-[10px] uppercase tracking-wider text-slate-400">Linha de Apoio</span>
              <a href="tel:923002202" className="text-sm font-bold text-slate-800 hover:underline">+244 923 002 202</a>
            </div>
          </div>
        </div>
      );
    }

    if (clientRestaurant) {
      // Check if restaurant plan is active. If expired or none, block access
      if (clientRestaurant.planStatus !== 'active') {
        return (
          <div className="min-h-screen bg-[#f8fafc] text-slate-800 flex flex-col items-center justify-center p-4 text-center space-y-5">
            <div className="h-16 w-16 bg-amber-500/10 border-2 border-amber-500 text-amber-500 rounded-full flex items-center justify-center animate-bounce">
              <Utensils className="h-8 w-8" />
            </div>
            <div className="space-y-2 max-w-md">
              <h2 className="font-display font-extrabold text-2xl text-slate-900">{clientRestaurant.name}</h2>
              <p className="text-slate-600 text-sm">
                O cardápio digital deste restaurante está temporariamente suspenso por questões de assinatura do plano de serviço.
              </p>
              <p className="text-xs text-slate-400">
                Se é o proprietário deste restaurante, por favor entre no painel administrativo e efetue o pagamento do plano para liberar o cardápio.
              </p>
            </div>
            <div className="bg-white border border-slate-200 shadow-sm p-4 rounded-xl flex items-center space-x-3.5 text-left max-w-sm">
              <Phone className="h-5 w-5 text-amber-500 shrink-0" />
              <div>
                <span className="font-semibold block text-[10px] uppercase tracking-wider text-slate-400">Apoio ao Cliente</span>
                <a href="tel:923002202" className="text-sm font-bold text-slate-800 hover:underline">+244 923 002 202</a>
              </div>
            </div>
          </div>
        );
      }

      return (
        <ClientView restaurant={clientRestaurant} />
      );
    }
  }

  // FIRST LOGIN / REGISTER NEW RESTAURANT FLOW
  if (isRegistering && user) {
    return (
      <div className="min-h-screen bg-[#f8fafc] text-slate-800 flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-md p-8 bg-white border border-slate-200 rounded-2xl shadow-xl space-y-6">
          <div className="text-center space-y-2">
            <div className="h-12 w-12 bg-amber-500 text-white rounded-xl flex items-center justify-center mx-auto text-xl font-bold shadow-md shadow-amber-500/20">
              🍽️
            </div>
            <h2 className="font-display font-extrabold text-2xl tracking-tight text-slate-900">Criar seu Restaurante</h2>
            <p className="text-slate-500 text-sm">
              Preencha o nome do seu estabelecimento comercial para criar a sua base de dados dedicada.
            </p>
          </div>

          <form onSubmit={handleCreateRestaurant} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                Nome do Restaurante *
              </label>
              <input
                id="reg-rest-name-input"
                type="text"
                value={newRestName}
                onChange={(e) => setNewRestName(e.target.value)}
                placeholder="Ex: Cantinho do Calulu, Grelha Imperial"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:bg-white transition-all"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                E-mail do Proprietário
              </label>
              <input
                type="text"
                value={user.email || ''}
                disabled
                className="w-full bg-slate-100 border border-slate-200 rounded-xl py-3 px-4 text-sm text-slate-500 font-mono cursor-not-allowed"
              />
            </div>

            <button
              id="btn-register-submit"
              type="submit"
              disabled={registerLoading}
              className="w-full bg-amber-500 hover:bg-amber-600 text-white font-semibold py-3.5 px-4 rounded-xl flex items-center justify-center space-x-2 shadow-md shadow-amber-500/20 transition-all cursor-pointer"
            >
              {registerLoading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>A provisionar dados...</span>
                </>
              ) : (
                <>
                  <span>Criar Painel do Restaurante</span>
                </>
              )}
            </button>
          </form>

          <button
            onClick={handleLogout}
            className="w-full text-center text-slate-400 hover:text-slate-600 text-xs transition-colors"
          >
            Sair da Conta / Cancelar
          </button>
        </div>
        {renderAdminGodBypass()}
      </div>
    );
  }

  // ADMIN VIEW IF LOGGED IN
  if (user && (restaurant || isAdminGod)) {
    const activeRestaurant = restaurant || {
      id: user.uid,
      name: 'ChefExpress Admin Portal',
      description: 'Painel Geral de Controle',
      ownerId: user.uid,
      ownerEmail: user.email || 'admin@chefexpress.ao',
      supportPhone: '923002202',
      logoUrl: '👑',
      activePlan: 'gold',
      planStatus: 'active',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    } as Restaurant;

    return (
      <div className="min-h-screen bg-[#f8fafc] text-slate-800 flex flex-col justify-between">
        <div>
          <Navbar 
            user={user} 
            restaurant={activeRestaurant} 
            onLogout={handleLogout} 
            activeTab={activeTab} 
            setActiveTab={setActiveTab} 
          />
          <AdminDashboard 
            user={user} 
            restaurant={activeRestaurant} 
            onUpdateRestaurant={setRestaurant} 
            activeTab={activeTab} 
            setActiveTab={setActiveTab} 
            isAdminGod={isAdminGod}
          />
        </div>

        {/* Small persistent professional workspace footer */}
        <footer className="py-6 border-t border-slate-200 text-center text-slate-500 text-xs font-mono space-y-1 bg-white max-w-7xl mx-auto w-full px-4">
          <p>Gerenciador de Restaurante &copy; 2026. Todos os direitos reservados por Nazael Diniz Alves Primo Giblin.</p>
          <p className="text-[10px] text-slate-400">Apoio técnico autorizado ao cliente: 923002202 | Angola</p>
        </footer>

        {renderAdminGodBypass()}
      </div>
    );
  }

  // PUBLIC OWNER LANDING / PORTAL (BEFORE LOGIN)
  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-800 flex flex-col justify-between">
      {/* Top landing header support */}
      <header className="px-4 py-4 sm:px-6 border-b border-slate-200 bg-white shadow-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="h-9 w-9 bg-amber-500 rounded-xl flex items-center justify-center font-black text-white shadow-sm">
              🍽️
            </div>
            <span className="font-display font-extrabold text-base sm:text-lg text-[#0f172a] tracking-tight">
              ChefExpress
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => window.open(window.location.href, '_blank')}
              className="text-xs font-semibold text-amber-600 hover:text-amber-700 bg-amber-50 border border-amber-200 py-1.5 px-3 rounded-lg flex items-center space-x-1 transition-colors cursor-pointer"
            >
              <span>Abrir em Nova Aba ↗</span>
            </button>
            <a
              href="tel:923002202"
              className="text-xs font-semibold text-slate-600 hover:text-slate-800 bg-slate-50 border border-slate-200 py-1.5 px-3 rounded-lg flex items-center space-x-1 transition-colors"
            >
              <Phone className="h-3.5 w-3.5 text-amber-500" />
              <span>Apoio: 923002202</span>
            </a>
          </div>
        </div>
      </header>

      {/* Hero Body */}
      <main className="max-w-7xl mx-auto px-4 py-12 sm:py-20 flex-1 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        {authError && (
          <div className="lg:col-span-12 bg-rose-50 border border-rose-100 p-5 rounded-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4 text-[#0f172a] text-xs">
            <div className="space-y-1 text-left">
              <div className="flex items-center gap-2 text-rose-600 font-bold text-sm">
                <span className="text-base">⚠️</span>
                <span>Restrição de Iframe do Navegador</span>
              </div>
              <p className="leading-relaxed font-medium text-rose-700 max-w-4xl">
                {authError}
              </p>
            </div>
            <button
              onClick={() => window.open(window.location.href, '_blank')}
              className="whitespace-nowrap bg-amber-500 hover:bg-amber-600 text-white font-extrabold py-2.5 px-5 rounded-xl shadow-sm cursor-pointer transition-colors text-xs"
            >
              Abrir em Nova Aba ↗
            </button>
          </div>
        )}
        
        {/* Left pitch copy */}
        <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
          <div className="inline-flex items-center space-x-1.5 text-xs text-amber-500 font-semibold bg-amber-500/10 px-3.5 py-1.5 rounded-full border border-amber-500/20">
            <ChefHat className="h-3.5 w-3.5" />
            <span>Inovação para o seu Restaurante em Angola</span>
          </div>
          <h1 className="font-display font-black text-4xl sm:text-5xl xl:text-6xl text-[#0f172a] leading-tight tracking-tight max-w-2xl mx-auto lg:mx-0">
            Gerencie o seu cardápio, receba pedidos em <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-500 to-orange-500">tempo real</span>
          </h1>
          <p className="text-slate-600 text-sm sm:text-base max-w-xl mx-auto lg:mx-0 leading-relaxed">
            Habilite o autoatendimento e controle as entregas na mesa ou ao domicílio de forma 100% digital. Crie o seu cardápio, gere o seu link de autoatendimento exclusivo e comece a faturar hoje.
          </p>

          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
            <button
              id="landing-login-btn"
              onClick={handleGoogleLogin}
              className="w-full sm:w-auto bg-amber-500 hover:bg-amber-600 text-white font-extrabold py-4 px-8 rounded-xl text-sm transition-all shadow-md shadow-amber-500/20 flex items-center justify-center space-x-2 cursor-pointer group"
            >
              <Smartphone className="h-4.5 w-4.5 group-hover:-translate-y-0.5 transition-transform" />
              <span>Registrar ou Entrar no Painel</span>
            </button>
            <a
              href="#pricing"
              className="text-slate-500 hover:text-slate-800 font-semibold text-xs py-3 px-5 transition-colors"
            >
              Ver Planos de Assinatura &rarr;
            </a>
          </div>

          {/* Quick bullet summaries */}
          <div className="pt-6 grid grid-cols-1 sm:grid-cols-3 gap-4 border-t border-slate-200 max-w-xl mx-auto lg:mx-0">
            {[
              { title: 'Pedidos Express', desc: 'Sinalização com alertas sonoros na cozinha' },
              { title: 'Link de Cliente', desc: 'Aceda sem necessidade de downloads' },
              { title: 'Gestão Angola', desc: 'Ativações fáceis por Multicaixa Express' }
            ].map((bullet, idx) => (
              <div key={idx} className="text-center lg:text-left space-y-1">
                <span className="text-[#0f172a] font-bold text-xs block">{bullet.title}</span>
                <span className="text-slate-500 text-[11px] block">{bullet.desc}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Right side Pricing/Sub Preview */}
        <div id="pricing" className="lg:col-span-5 bg-white border border-slate-200 p-6 rounded-3xl space-y-6 relative overflow-hidden shadow-xl">
          <div className="absolute top-0 right-0 h-28 w-28 bg-amber-500/5 rounded-full blur-2xl" />
          
          <div className="space-y-1 text-center sm:text-left">
            <h3 className="font-display font-bold text-lg text-[#0f172a]">Nossos Planos de Serviço</h3>
            <p className="text-xs text-slate-500">Ativação imediata de 30 dias por Multicaixa Express no número 923002202.</p>
          </div>

          <div className="space-y-3">
            {[
              PLAN_DETAILS.bala,
              PLAN_DETAILS.plus_bala,
              PLAN_DETAILS.gold,
            ].map(plan => (
              <div 
                key={plan.id}
                className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between gap-4 hover:border-slate-300 transition-colors"
              >
                <div className="space-y-1 text-left">
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-xs text-[#0f172a]">{plan.name}</span>
                    <span className="text-[9px] bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded font-mono font-bold">
                      {plan.servicePercent}% Serviço
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-500">Capacidade: {plan.maxMenuItems === 999 ? 'Ilimitada' : `Até ${plan.maxMenuItems} pratos`}</p>
                </div>
                <div className="text-right">
                  <span className="font-mono text-sm font-black text-amber-500 block">{plan.priceFormatted}</span>
                  <span className="text-[9px] text-slate-400 font-semibold block">/ Mensal</span>
                </div>
              </div>
            ))}
          </div>

          <button
            onClick={handleGoogleLogin}
            className="w-full py-3.5 bg-slate-800 hover:bg-slate-900 border border-slate-700 rounded-xl text-xs font-bold text-slate-300 hover:text-white transition-all cursor-pointer text-center"
          >
            Acessar com Conta Google para Assinar
          </button>
        </div>

      </main>

      {/* Footer helpline details */}
      <footer className="py-6 px-4 border-t border-slate-200 text-center text-slate-500 text-xs font-mono space-y-2 bg-white">
        <p>ChefExpress Angola &copy; 2026. Todos os direitos reservados de propriedade por Nazael Diniz Alves Primo Giblin.</p>
        <div className="flex justify-center items-center space-x-2 text-[10px] text-slate-400">
          <Phone className="h-3 w-3 text-amber-500" />
          <span>Apoio e Ativações Multicaixa Express: <strong>923002202</strong></span>
        </div>
      </footer>

      {renderAdminGodBypass()}
    </div>
  );
}
